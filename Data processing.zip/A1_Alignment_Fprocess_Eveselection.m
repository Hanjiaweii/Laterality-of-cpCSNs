clc;clear;close all;
%% 输入数据
filename='H:\p01\Left\d01\';%数据存放路径
load([filename,'\','Fall']);
C = csvread([filename,'cs08_d09_left-001_Cycle00001_VoltageRecording_001.csv']);
angle=load([filename,'cs08_d09_left.txt']);
cue=C(:,3);
angle_data=angle(:,4);

%% 计算cue信号与双光子信号之间的时间差
tseries_beginning=[22,03,08,806];
cue_beginning=[22,03,07,247];
tseries_frame_original=18223;
gap=tseries_beginning-cue_beginning;
time_gap=gap(1,1)*3600000+gap(1,2)*60000+gap(1,3)*1000+gap(1,4);
frame_gap=floor(time_gap/33.474227);

%% 将双光子图像数据与cue对齐
cue_fps=1000;
angle_fps=200;
frame_fps=30;
angle_downsample=resample(angle_data,frame_fps,angle_fps);
widthmean=25;
for i=1+widthmean:size(cue,1)-widthmean
cue_filter(1,i)=mean(cue(i-widthmean:i+widthmean));
end
for i=1:size(cue_filter,2)
if cue_filter(1,i)>1
cue_filter(1,i)=3.3;
else
cue_filter(1,i)=0;
end
end
cue_downsample=resample(cue_filter,frame_fps,cue_fps);
for i=1:size(cue_downsample,2)
if cue_downsample(1,i)>1
cue_downsample(1,i)=3.3;
else
cue_downsample(1,i)=0;
end
end
up=find(cue_downsample==3.3);
cue_beginning=up(1,1);
frame_beginning=cue_beginning-frame_gap;

%% cue与运动数据对齐，并对三种cue赋值
cue_new1=cue_downsample(cue_beginning:end);
if  size(angle_downsample,1)<size(cue_new1,2)
tseries_frame=(frame_beginning:frame_beginning+size(angle_downsample,1)-1);
else
tseries_frame=(frame_beginning:frame_beginning+size(cue_new1,2)-1);
end
if  size(angle_downsample,1)>size(cue_new1,2)
x=angle_downsample(1:size(cue_new1,2),1);
angle_downsample=[];
angle_downsample=x;
end
if size(angle_downsample,1)<size(cue_new1,2)
cue_new2=cue_new1(1:size(angle_downsample,1));
else
cue_new2=cue_new1;
end
cue_new2(1,1)=0;
up1=find(diff(cue_new2)>3);
up2=find(diff(up1)>5);
down1=find(diff(cue_new2)<-3);
down2=find(diff(down1)>5);
cue_marker=zeros(1,size(cue_new2,2));
trial_selected=[];
for i=1:size(down2,2)
trial_selected(i,1)=up1(up2(i))+1;
trial_selected(i,2)=down1(down2(i))+1;
trial_selected(i,3)=trial_selected(i,2)-trial_selected(i,1);
end
%根据cue的时长不同对cue的类型进行定义%
for j=1:size(trial_selected,1)
if trial_selected(j,3)>10&&trial_selected(j,3)<20
cue_marker(trial_selected(j,1):trial_selected(j,2))=2;
end
if trial_selected(j,3)<10
cue_marker(trial_selected(j,1):trial_selected(j,2))=3; 
end
if trial_selected(j,3)>25
cue_marker(trial_selected(j,1):trial_selected(j,2))=1;
end
end
cue_marker(1,1)=1;

%% 判断双光子数据是否滞后,对所有对齐数据置空
delete_pos=find(tseries_frame<=0);
if size(delete_pos)>0
tseries_frame(delete_pos)=[];
cue_marker(delete_pos)=[];
angle_downsample(delete_pos)=[];
end
save([filename,'angle_downsample'],'angle_downsample');%运动数据
save([filename,'cue_marker'],'cue_marker');%cue
save([filename,'tseries_frame'],'tseries_frame');%对应帧数

%% 截取F和Fneu
F_processed=F(:,tseries_frame); %选择正确的tseries时间%
Fneu_final=Fneu(:,tseries_frame); %选择正确的tseries时间%
% 去背景后的F值
F_second=F_processed-0.7*Fneu_final;
% 转置cue_marker
cue_marker_final=cue_marker.';
% 转置F值
F_final=F_second.';
save([filename,'cue_marker_final'],'cue_marker_final');
save([filename,'F_final'],'F_final');

%% 计算dF/F值
neu_num=find(iscell(:,1)==1);
sigt=F_final(:,neu_num)';
window_length=450;
for neu=1:size(sigt,1)
for t=window_length+1:size(sigt, 2)-window_length
f0(neu,t)=mean(sigt(neu,t-window_length:t+window_length)); 
end
end
for neu=1:size(sigt, 1)
f0(neu,1:window_length)=f0(neu,window_length+1);
f0(neu,size(sigt, 2)-window_length+1:size(sigt, 2))=f0(neu,size(sigt, 2)-window_length);
end    
for neu =1:size(sigt, 1)
for t=1:size(sigt,2)
sigtdf(neu,t)=(sigt(neu,t)-f0(neu,t))/f0(neu,t);
end
end
for neu=1:size(sigtdf,1)
sigtdf(neu,:)=normalize(sigtdf(neu,:));
end

%% 找到calcium events 
for neu=1:size(sigtdf,1)
[frames amplitudes] = AP_trace_peak(sigtdf(neu,:));
peak_frames{1,neu}=frames;
peak_amplitudes{1,neu}=amplitudes;
end

for neu=1:size(sigtdf,1)
sigt_before=sigtdf(neu,:);
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
event_segment=sigt_before(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_frames{1,neu}{1,1}(1,peak_num)+30);
peak_pos=find(event_segment==max(event_segment));
peak_end_frames{1,neu}(1,peak_num)=peak_frames{1,neu}{1,1}(1,peak_num)+peak_pos;
end

else
peak_end_frames{1,neu}=[];
end
end

%% 根据每次event peak和baseline之间的差值更新
for neu=1:size(sigtdf,1)
sigt_after=zeros(1,size(sigtdf(neu,:),2));
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
sigt_after(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_end_frames{1,neu}(1,peak_num))=peak_amplitudes{1,neu}{1,1}(1,peak_num);
end
end
calcium_event(neu,:)=sigt_after;
end
save([filename,'\','calcium_event'],'calcium_event');

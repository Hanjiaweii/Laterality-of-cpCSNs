clc;close all;clear

filename='H:\p15\Right\d29';
load([filename,'\angle_downsample']);

%% ���˶����ݽ���Ԥ����
% remove baseline
baseline_removed=detrend(angle_downsample,'constant');
for i=1:size(baseline_removed,2)
baseline_removed(i)=(baseline_removed(i)>=0)*baseline_removed(i);
end
xx=sort(baseline_removed);
baseline=mean(xx(1:5000));
for i=1:size(baseline_removed,1)
if baseline_removed(i)<baseline
 baseline_removed(i)=baseline;
end
end
angle_processed=baseline_removed;

%% ���˶�״̬���
figure(1)
diff_angle=diff(angle_processed);
movement_frames=find(abs(diff_angle)>0.22);
plot(angle_processed);
hold on;
yl=ylim;

for i=1:size(movement_frames,1) 
line([movement_frames(i,1)+1 movement_frames(i,1)+1],[yl(1) yl(2)],'color',[0.8 0.8 0.8]);
end
plot(angle_processed);

save([filename,'\','movement_frames'],'movement_frames');

%% �˶�����ת��
angle_marker=zeros(1,size(angle_downsample,1));
angle_marker(1,movement_frames)=1;

%% ��ȡ���˶���ʼ��λ��
quiet_state=zeros(1,30);
k=0;
for  i=1:size(angle_marker,2)-30
% quiet_or_not=isequal(angle_marker(1,i:i+29), quiet_state);
% if quiet_or_not==1
quiet_or_not=sum(angle_marker(1,i:i+29));
if quiet_or_not<=1   %30֡��������С�ڵ���2֡���˶�״̬�Կ���Ϊ����%
k=k+1;
movement_onset_all(k,1)=i;
end
end

%% ɾ���ظ��Ŀ�ʼλ��
diff_onset=diff(movement_onset_all);
pos=find(diff_onset>1);
for i=1:size(pos,1)
movement_onset(i,1)=movement_onset_all(pos(i,1));
end

%% �жϽ�ȡ���˶�Ƭ�����Ƿ���������������˶�
for i=1:size(movement_onset,1)
movement_epoch(i,1)=movement_onset(i,1);
movement_epoch(i,2)=movement_onset(i,1)+89;
end
q=0;
for i=1:size(movement_epoch,1)
angle_epoch=angle_marker(1,movement_epoch(i,1)+30:movement_epoch(i,2));
movement_time=sum(angle_epoch);
if movement_time>=14  %30֡���ߺ����60֡������ڵ���10֡���˶�״̬�Կ���Ϊ�˶���%
q=q+1;
select_movement_pos(1,q)=i;
end
end 
movement_epoch_select1=movement_epoch(select_movement_pos,:);

%% ɾ���н����trial
diff_select=diff(movement_epoch_select1(:,1));
pos2=find(diff_select>30);
if pos2(1,1)==1
pos2=[0;pos2];
end
movement_epoch_select=movement_epoch_select1(pos2+1,:);

%% ������trial������ƽ
for i=1:size(movement_epoch_select,1)
baseline_diff=min(angle_processed(movement_epoch_select(i,1):movement_epoch_select(i,1)+29)); 
movement_data(i,:)=angle_processed(movement_epoch_select(i,1):movement_epoch_select(i,2))-baseline_diff;
end

save([filename,'\','movement_data'],'movement_data');

%% plot��ȡ��movement epoch
figure(2)
baseline_removed=detrend(angle_downsample,'constant');
for i=1:size(baseline_removed,2)
baseline_removed(i)=(baseline_removed(i)>=0)*baseline_removed(i);
end
xx=sort(baseline_removed);
baseline=mean(xx(1:5000));
for i=1:size(baseline_removed,1)
if baseline_removed(i)<baseline
 baseline_removed(i)=baseline;
end
end
angle_processed=baseline_removed;
angle=normalize(angle_processed);
plot(angle);
hold on 
yl=ylim;
for i=1:size(movement_frames,1) 
line([movement_frames(i,1)+1 movement_frames(i,1)+1],[yl(1) yl(2)],'color',[0.8 0.8 0.8]);
end
hold on;
for i=1:size(movement_epoch_select,1)
line([movement_epoch_select(i,1) movement_epoch_select(i,1)],[0,1],'color','b','linewidth',1);
hold on;
line([movement_epoch_select(i,2) movement_epoch_select(i,2)],[0,1],'color','r','linewidth',1);
hold on;
end

save([filename,'\','movement_epoch_select'],'movement_epoch_select');

%% �����ȡ��movement epoch frames
%������trial������ƽ
for i=1:size(movement_epoch_select,1)
baseline_diff=min(angle_processed(movement_epoch_select(i,1):movement_epoch_select(i,1)+29)); 
movement_epoch_frames(i,:)=angle_processed(movement_epoch_select(i,1):movement_epoch_select(i,1)+89)-baseline_diff;
end

figure(3)
for i=1:size(movement_epoch_frames,1)
plot(movement_epoch_frames(i,:));
hold on;
end

save([filename,'\','movement_epoch_frames'],'movement_epoch_frames');



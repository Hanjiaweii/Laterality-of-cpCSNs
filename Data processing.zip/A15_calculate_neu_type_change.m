clc;close all ;clear;
%% data input
 part1=[3]; %part代表Fall的顺序
 part2=[];
 part3=[13];
 part4=[27];
 part5=[];
 session_num=[part1,part2,part3,part4,part5];
filename1='H:\p01';

for i=1:size(session_num,2)
load([filename1,'\','neuron_LI_',num2str(session_num(1,i))]);
neu_type_all{1,i}=neuron_LI;
end
 filename2='H:\p01\Overlapped Neurons1';
 load([filename2,'\','session_pos']);
 session_part=[{part1},{part2},{part3},{part4},{part5}];
 
 class_type=2;  %1是分五类，2是分3类
 
 %% 矩阵重组
 for i=1:size(session_part,2) 
 XX=[];
 for j=1:size(session_part{1,i},2)
XX(:,j)=session_pos(:,i);
 end
 session_pos_new_all{1,i}=XX;
 end
YY=[];
 for i=1:size(session_pos_new_all,2)
YY=[YY,session_pos_new_all{1,i}];
 end
 session_pos_new=YY;
  
for neu=1:size(session_pos_new,1)
 for  s=1:size(session_pos_new,2)
 if session_pos_new(neu,s)>0
 neu_changes(neu,s)=neu_type_all{1,s}(session_pos_new(neu,s),1);
 else
 neu_changes(neu,s)=5;
 end
 end
end

if  class_type==2
for i=1:size(neu_changes,1)
 for j=1:size(neu_changes,2)
if neu_changes(i,j)<0
    neu_LI(i,j)=1;
end
if neu_changes(i,j)>0&&neu_changes(i,j)<5
    neu_LI(i,j)=2;
end
  if neu_changes(i,j)==5
    neu_LI(i,j)=5;    
  end
  end
end
end

if  class_type==1
for i=1:size(neu_changes,1)
 for j=1:size(neu_changes,2)
if neu_changes(i,j)==-1
    neu_LI(i,j)=1;
end
if neu_changes(i,j)==1
    neu_LI(i,j)=2;
end
  if neu_changes(i,j)==5
    neu_LI(i,j)=5;    
  end
 if neu_changes(i,j)>0&&neu_changes(i,j)<1
    neu_LI(i,j)=4;
 end
  if neu_changes(i,j)>-1&&neu_changes(i,j)<0
    neu_LI(i,j)=3;
  end
 end
end
end

     for  i=1:size(neu_LI,2)
     zero_pos{1,i}=find(neu_LI(:,i)==5);
     end
    zero=union(union( zero_pos{1,1}, zero_pos{1,2}), zero_pos{1,3});
    % zero=union( zero_pos{1,1}, zero_pos{1,2});
    overlap_neu_pos=setdiff(1:1:size(neu_LI,1),zero);
    neu_overlap_LI=neu_LI(overlap_neu_pos,:);
 %% 统计各类神经元具体的变化情况
chosen_s1=neu_overlap_LI(:,1);
chosen_s2=neu_overlap_LI(:,2);
%第一列是早期，第二列是中期，第三列是晚期
%若看早中期的变化，选择12两列，看早晚期的变化，选13两列，以此类推
if class_type==1
class=[0,1,2,3,4];
else
 class=[0,1,2];
end

 for type=1:size(class,2)
 tar_neu_pos=find(chosen_s1==class(1,type));
 tar_neu=chosen_s2( tar_neu_pos);
 tar_neu_num(type,1)=size(tar_neu_pos,1)/size(chosen_s1,1);
 k=zeros(1,size(class,2));tar_class=class;
 for neu=1:size(tar_neu,1)
 for t=1:size(tar_class,2)
 if tar_neu(neu)==tar_class(1,t)
 k(1,t)= k(1,t)+1;
 end
 end
 end
 type_all(type,:)=k/size(chosen_s1,1);
 end



     
     
     
 
 
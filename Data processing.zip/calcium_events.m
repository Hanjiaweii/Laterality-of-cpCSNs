clear
close all
clc;

%% data input

days_marker=19:1:19;

for d=1:size(days_marker,2)
 if days_marker(1,d)<10
filename=['E:\Corticospinal Data\p21\Right\d0',num2str(days_marker(1,d)),'\'];
 end
 if days_marker(1,d)>=10
filename=['E:\Corticospinal Data\p21\Right\d',num2str(days_marker(1,d)),'\'];
 end
 
 load([filename,'\','sigtdf']);
%% dF/Fֵ����һ��
% 
%  for neu=1:size(sigtdf,1)
%  sigtdf(neu,:)=normalize(sigtdf(neu,:));
%  end

%% �ҵ�calcium events 
for neu=1:size(sigtdf,1)
[frames amplitudes] = AP_trace_peak(sigtdf(neu,:));
peak_frames{1,neu}=frames;
peak_amplitudes{1,neu}=amplitudes;
end

for neu=1:size(sigtdf,1)
sigt_before=sigtdf(neu,:);
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
event_segment=sigt_before(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_frames{1,neu}{1,1}(1,peak_num)+30);
peak_pos=find(event_segment==max(event_segment));
peak_end_frames{1,neu}(1,peak_num)=peak_frames{1,neu}{1,1}(1,peak_num)+peak_pos;
end

else

peak_end_frames{1,neu}=[];
end
end

%% ����ÿ��event peak��baseline֮��Ĳ�ֵ����
for neu=1:size(sigtdf,1)
sigt_after=zeros(1,size(sigtdf(neu,:),2));
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
sigt_after(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_end_frames{1,neu}(1,peak_num))=peak_amplitudes{1,neu}{1,1}(1,peak_num);
end
end
calcium_event(neu,:)=sigt_after;
end

save([filename,'\','calcium_event'],'calcium_event');
calcium_event=[];
end

%% 输入各个sessio校正后roi的位置
[filenames, path] = uigetfile('*.mat','Choose mat files','on');
load([path,'neu_pos.mat']);

% % 获取每个session的ROI个数
for i = 1:7
ROI_num(i,1) = size(neu_pos{1,i},1);
end;
% % 获取每两个session的Overlapped ROI个数
for i = 1:7
ROI_num(i,1) = size(neu_pos{1,i},1);
end;
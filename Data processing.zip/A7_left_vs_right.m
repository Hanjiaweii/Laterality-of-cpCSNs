clc;clear;close all
%% data input
days_marker=[5,7,8,14,18,22];
for d=1:size(days_marker,2)
    filename='E:\Corticospinal Data\g19\';
    if days_marker(1,d)<10
    filename1=[filename,'Left\d0',num2str(days_marker(1,d)),'\'];
    filename2=[filename,'Right\d0',num2str(days_marker(1,d)),'\'];
    end
    if days_marker(1,d)>=10
   filename1=[filename,'Left\d',num2str(days_marker(1,d)),'\'];
   filename2=[filename,'Right\d',num2str(days_marker(1,d)),'\'];
    
    end

load([filename1,'\ca_mean_select_left.mat']);
sigt_left=ca_mean_select_left;
 load([filename2,'\ca_mean_select_right.mat']);
sigt_right=ca_mean_select_right;
 load([filename,'\neuron_LI_new_',num2str(days_marker(1,d))]);

%% ������Ԫ���Ҳ�Ա�
% for i=1:size(sigt_left,1)
% figure(i)
% plot(sigt_left(i,:),'b');
% hold on
% plot(sigt_right(i,:),'r');
% legend('left','right');
% end
neuron_LI_after=[];
 for i=1:size(neuron_LI,1)
if neuron_LI(i,1)==-1 %ipsi
    neuron_LI_after(i,1)=1;
end
if neuron_LI(i,1)==1 %con
    neuron_LI_after(i,1)=2;
end
 if neuron_LI(i,1)>0&&neuron_LI(i,1)<1 %bilateral-contra
     neuron_LI_after(i,1)=3;
 end
  if neuron_LI(i,1)>-1&&neuron_LI(i,1)<0 %bilateral-ipsi
     neuron_LI_after(i,1)=3;
  end
 end


%% ��ͬ��ԪȺ������Ҳ�Ա�
for i=1:3
neu1=find(neuron_LI_after==i);
sigt_left_neu=sigt_left(neu1,:);
sigt_right_neu=sigt_right(neu1,:);
if size(neu1,1)>1
sum_left(i,:)=sum(sigt_left_neu);
mean_left(i,:)=mean(sigt_left_neu);
se_left(i,:)=sem(sigt_left_neu);
sum_right(i,:)=sum(sigt_right_neu);
mean_right(i,:)=mean(sigt_right_neu);
se_right(i,:)=sem(sigt_right_neu);
end
if size(neu1,1)==1
sum_left(i,:)=sigt_left_neu;
mean_left(i,:)=sigt_left_neu;
se_left(i,:)=zeros(1,60);
sum_right(i,:)=sigt_right_neu;
mean_right(i,:)=sigt_right_neu;
se_right(i,:)=zeros(1,60);
end
if size(neu1,1)==0
sum_left(i,:)=zeros(1,60);
mean_left(i,:)=zeros(1,60);
se_left(i,:)=zeros(1,60);
sum_right(i,:)=zeros(1,60);
mean_right(i,:)=zeros(1,60);
se_right(i,:)=zeros(1,60);
end


end
left{d,1}=sum_left;
right{d,1}=sum_right;
sigt_left_neu=[];
sigt_right_neu=[];
sum_left=[];
sum_right=[];
mean_left=[];
mean_right=[];
se_left=[];
se_right=[];


end

clc;close all ;clear;
%% data input
part1=[5,7,8];
part2=[14];    %part对应Fall的次序, 第一个Fall对应part1
 part3=[18];
 part4=[22];
 part5=[];
 session_num=[part1,part2,part3,part4,part5];
filename1='E:\Corticospinal Data\g19';
marker_type=2;%1是01234，2是LI
if marker_type==1
for i=1:size(session_num,2)
 if session_num(1,i)<10
load([filename1,'\','neuron_df_marker_0',num2str(session_num(1,i))]);
neu_type_all{1,i}=neuron_marker;
 else
load([filename1,'\','neuron_df_marker_',num2str(session_num(1,i))]);
neu_type_all{1,i}=neuron_marker;
 end
end
end
if marker_type==2
for i=1:size(session_num,2)
load([filename1,'\','neuron_LI_new_',num2str(session_num(1,i))]);
neu_type_all{1,i}=neuron_LI;
end
end

 filename2='E:\Corticospinal Data\g19\Overlapped Neurons1';
 load([filename2,'\','session_pos']);
 session_part=[{part1},{part2},{part3},{part4},{part5}];
 
  for i=1:size(neu_type_all,2) 
 neuron_LI=neu_type_all{1,i};
 a1=find(neuron_LI==0);
 neu_per(1,i)=size(a1,1)/size(neuron_LI,1);
  a2=find(neuron_LI==-1);
 neu_per(2,i)=size(a2,1)/size(neuron_LI,1);
   a3=find(neuron_LI==1);
 neu_per(3,i)=size(a3,1)/size(neuron_LI,1);
    a4=find(neuron_LI<0);
 neu_per(4,i)=(size(a4,1)-size(a2,1))/size(neuron_LI,1);
     a5=find(neuron_LI>0);
 neu_per(5,i)=(size(a5,1)-size(a3,1))/size(neuron_LI,1);
 neuron_LI=[];a1=[];a2=[];a3=[];a4=[];a5=[];
  end
 
 %% 矩阵重组
 for i=1:size(session_part,2) 
 XX=[];
 for j=1:size(session_part{1,i},2)
XX(:,j)=session_pos(:,i);
 end
 session_pos_new_all{1,i}=XX;
 end
YY=[];
 for i=1:size(session_pos_new_all,2)
YY=[YY,session_pos_new_all{1,i}];
 end
 session_pos_new=YY;
  
 if  marker_type==1
 for neu=1:size(session_pos_new,1)
 for  s=1:size(session_pos_new,2)
 if session_pos_new(neu,s)>0
 neu_changes(neu,s)=neu_type_all{1,s}(1, session_pos_new(neu,s));
 else
 neu_changes(neu,s)=5;
 end
 end
 end
 end

 if  marker_type==2
for neu=1:size(session_pos_new,1)
 for  s=1:size(session_pos_new,2)
 if session_pos_new(neu,s)>0
 neu_changes(neu,s)=neu_type_all{1,s}(session_pos_new(neu,s),1);
 else
 neu_changes(neu,s)=5;
 end
 end
 end
 for i=1:size(neu_changes,1)
 for j=1:size(neu_changes,2)
if neu_changes(i,j)==-1
    neu_LI(i,j)=1;
end
if neu_changes(i,j)==1
    neu_LI(i,j)=2;
end
  if neu_changes(i,j)==5
    neu_LI(i,j)=5;    
  end
 if neu_changes(i,j)>0&&neu_changes(i,j)<1
    neu_LI(i,j)=4;
 end
  if neu_changes(i,j)>-1&&neu_changes(i,j)<0
    neu_LI(i,j)=3;
  end
 end
 end
  end
 
 
 
 
 %%  plot
 if  marker_type==1
 figure(1)
%  x=1:1:s;
%  y=1:1:neu;
%  [X,Y]=meshgrid(x,y);
 imagesc(neu_changes);
c(1,:)=[1,1,1];
c(2,:)=[0,0.44,0.74];
c(3,:)=[0.85,0.32,0.09];
c(4,:)=[0.46,0.67,0.18];
c(5,:)=[0,0,0];
  colormap(c);
 % 只画出稳定出现的神经元
 figure(2)
 for  i=1:size(session_pos,2)
 zero_pos{1,i}=find(session_pos(:,i)==0);
 end
%  zero=union(union(zero_pos{1,1}, zero_pos{1,2}));
%zero=union(union( zero_pos{1,1}, zero_pos{1,2}), zero_pos{1,3});
zero=union(union(union( zero_pos{1,1}, zero_pos{1,2}), zero_pos{1,3}),zero_pos{1,4});
 overlap_neu_pos=setdiff(1:1:size(session_pos,1),zero);
 a=sortrows(neu_changes(overlap_neu_pos,:),1);
 imagesc(a);
 end
 
  if  marker_type==2
 figure(1)
%  x=1:1:s;
%  y=1:1:neu;
%  [X,Y]=meshgrid(x,y);
 imagesc(neu_LI);
c(1,:)=[1,1,1];
c(2,:)=[0.93,0.69,0.13];
c(3,:)=[0,0.45,0.74];
c(4,:)=[1,0.41,0.16];
c(5,:)=[0.07,0.62,1];
c(6,:)=[0,0,0];
  colormap(c);
 % 只画出稳定出现的神经元
 figure(2)
 for  i=1:size(session_pos,2)
 zero_pos{1,i}=find(session_pos(:,i)==0);
 end
% zero=union(zero_pos{1,1}, zero_pos{1,2});
zero=union(union( zero_pos{1,1}, zero_pos{1,2}), zero_pos{1,3});
% zero=union(union(union( zero_pos{1,1}, zero_pos{1,2}), zero_pos{1,3}),zero_pos{1,4});
%zero=union(union(union(union( zero_pos{1,1}, zero_pos{1,2}), zero_pos{1,3}),zero_pos{1,4}),zero_pos{1,5});
 overlap_neu_pos=setdiff(1:1:size(session_pos,1),zero);
 a=sortrows(neu_LI(overlap_neu_pos,:),1);
 neu_overlap_LI=neu_changes(overlap_neu_pos,:);
 imagesc(a);
% c2(1,:)=[1,1,1];
% c2(2,:)=[0.93,0.69,0.13];%同侧
% c2(3,:)=[0,0.45,0.74];%对侧
% c2(4,:)=[1,0.41,0.16];%双偏同
% c2(5,:)=[0.07,0.62,1];%双偏对

c2(1,:)=[1,1,1];
c2(2,:)=[1,0,0];%同侧
c2(3,:)=[0,0,1];%对侧
c2(4,:)=[1,0.7,0.2];%双偏同
c2(5,:)=[1,0.7,0.2];%双偏对

 colormap(c2);
 
 for i=1:size(neu_overlap_LI,2)
figure(3+i-1)
tar=abs(neu_overlap_LI(:,i));
pos=find(tar>0);
neuron_LI_se=neu_overlap_LI(pos,i);
[y,x]=hist(neuron_LI_se,1001); 
y=y/length(neuron_LI_se);   
X=-1:0.002:1;
Y=cumsum(y);
plot(X,Y);
ylim([0,1]);
half_pos=find(Y>=0.5);
x_half_pos(i,1)=X(half_pos(1,1));
 end 
  
  
end

if marker_type==1
 save([filename2,'\','neu_type_change_new'],'neu_changes');
else
save([filename2,'\','neu_LI_change_new'],'neu_changes'); 
save([filename2,'\','neu_overlap_LI_new'],'neu_overlap_LI'); 
end
  
 
 if marker_type==1
 %%统计各类神经元每天的百分比
%  for s=1:size(neu_changes,2)
% a1=find(neu_changes(:,s)<5);
% neu_num(1,s)=size(a1,1);
% a2=find(neu_changes(:,s)==0);
% neu_per(1,s)=size(a2,1)/neu_num(1,s);
% a3=find(neu_changes(:,s)==1);
% neu_per(2,s)=size(a3,1)/neu_num(1,s);
% a4=find(neu_changes(:,s)==2);
% neu_per(3,s)=size(a4,1)/neu_num(1,s);
% a5=find(neu_changes(:,s)==3);
% neu_per(4,s)=size(a5,1)/neu_num(1,s);
%  end
     
for s=1:size(a,2)
b1=find(a(:,s)<5);
neu_num2(1,s)=size(b1,1);
b2=find(a(:,s)==0);
neu_per2(1,s)=size(b2,1)/neu_num2(1,s);
b3=find(a(:,s)==1);
neu_per2(2,s)=size(b3,1)/neu_num2(1,s);
b4=find(a(:,s)==2);
neu_per2(3,s)=size(b4,1)/neu_num2(1,s);
b5=find(a(:,s)==3);
neu_per2(4,s)=size(b5,1)/neu_num2(1,s);
 end
 end   

 
 if marker_type==2
 %%统计各类神经元每天的百分比
%  for s=1:size(neu_LI,2)
% a1=find(neu_LI(:,s)<5);
% neu_num(1,s)=size(a1,1);
% a2=find(neu_LI(:,s)==0);
% neu_per(1,s)=size(a2,1)/neu_num(1,s);
% a3=find(neu_LI(:,s)==1);
% neu_per(2,s)=size(a3,1)/neu_num(1,s);
% a4=find(neu_LI(:,s)==2);
% neu_per(3,s)=size(a4,1)/neu_num(1,s);
% a5=find(neu_LI(:,s)==3);
% neu_per(4,s)=size(a5,1)/neu_num(1,s);
% a6=find(neu_LI(:,s)==4);
% neu_per(5,s)=size(a6,1)/neu_num(1,s);
%  end
     
for s=1:size(a,2)
b1=find(a(:,s)<5);
neu_num2(1,s)=size(b1,1);
b2=find(a(:,s)==0);
neu_per2(1,s)=size(b2,1)/neu_num2(1,s);
b3=find(a(:,s)==1);
neu_per2(2,s)=size(b3,1)/neu_num2(1,s);
b4=find(a(:,s)==2);
neu_per2(3,s)=size(b4,1)/neu_num2(1,s);
b5=find(a(:,s)==3);
neu_per2(4,s)=size(b5,1)/neu_num2(1,s);
b6=find(a(:,s)==4);
neu_per2(5,s)=size(b6,1)/neu_num2(1,s);
end

 end
 
 

clc;clear;close all

%% data input
days_marker=[3,4,9,13,24,26,27];
for d=1:size(days_marker,2)
    if days_marker(1,d)<10
    filename1=['H:\p01\Left\d0',num2str(days_marker(1,d)),'\'];
    filename2=['H:\p01\Right\d0',num2str(days_marker(1,d)),'\'];
    end
    if days_marker(1,d)>=10
    filename1=['H:\p01\Left\d',num2str(days_marker(1,d)),'\'];
    filename2=['H:\p01\Right\d',num2str(days_marker(1,d)),'\'];
    end
    
 epoch=30:45;   
 %left
load([filename1,'\','movement_epoch_frames']);
movement_left=movement_epoch_frames(:,epoch);
for i=1:size(movement_left,1)
X=movement_left(i,:);
peak_pos1=find(X==max(X));
trial_peak1(i,1)=peak_pos1(1,1);
 end
 movement_data_left=[movement_left,trial_peak1];
 movement_new1=sortrows(movement_data_left,size(epoch,2)+1);
 movement_se_left=movement_new1(floor(size(movement_new1,1)*0.2):ceil(size(movement_new1,1)*0.8),:);
for i=1:size(movement_left,1)
movement_left_se(i,:)=normalize(movement_left(i,:));
end
%right
load([filename2,'\','movement_epoch_frames']);
movement_right=movement_epoch_frames(:,epoch);
for i=1:size(movement_right,1)
Y=movement_right(i,:);
peak_pos2=find(Y==max(Y));
trial_peak2(i,1)=peak_pos2(1,1);
 end
 movement_data_right=[movement_right,trial_peak2];
 movement_new2=sortrows(movement_data_right,size(epoch,2)+1);
 movement_se_right=movement_new2(floor(size(movement_new2,1)*0.2):ceil(size(movement_new2,1)*0.8),:);
for i=1:size(movement_right,1)
movement_right_se(i,:)=normalize(movement_right(i,:));
end

%left within session
k=0;
for i=1:size(movement_left,1)-1
    for j=i+1:size(movement_left,1)
Y=[movement_left(i,:);movement_left(j,:)];
k=k+1;
E_within_left(k,1)=pdist(Y,'euclidean');
end
end
D_left(d,1)=mean(E_within_left);

%right within session
p=0;
for i=1:size(movement_right,1)-1
    for j=i+1:size(movement_right,1)
Y=[movement_right(i,:);movement_right(j,:)];
p=p+1;
E_within_right(p,1)=pdist(Y,'euclidean');
end
end
D_right(d,1)=mean(E_within_right);
%left vs right
q=0;
for i=1:size(movement_left,1)-1
    for j=1:size(movement_right,1)
Y=[movement_left(i,:);movement_right(j,:)];
q=q+1;
E_within(q,1)=pdist(Y,'euclidean');
end
end
D_left_right(d,1)=mean(E_within);
% left_mean vs right mean
movement_left_mean(d,:)=mean(movement_left_se);
movement_right_mean(d,:)=mean(movement_right_se);
X=[movement_left_mean(d,:);movement_right_mean(d,:)];
D=pdist(X,'euclidean');
E_dis(d,1)=D;

%left_se vs right_se
k=0;
for i=1:size(movement_left_se,1)-1
    for j=i+1:size(movement_left_se,1)
Z1=[movement_left_se(i,:);movement_left_se(j,:)];
k=k+1;
E_within_left_se(k,1)=pdist(Z1,'euclidean');
end
end
D_left_se(d,1)=mean(E_within_left_se);
p=0;
for i=1:size(movement_right_se,1)-1
    for j=i+1:size(movement_right_se,1)
Z2=[movement_right_se(i,:);movement_right_se(j,:)];
p=p+1;
E_within_right_se(p,1)=pdist(Z2,'euclidean');
end
end
D_right_se(d,1)=mean(E_within_right_se);
q=0;
for i=1:size(movement_left_se,1)-1
    for j=1:size(movement_right_se,1)
Z3=[movement_left_se(i,:);movement_right_se(j,:)];
q=q+1;
E_within_se(q,1)=pdist(Z3,'euclidean');
end
end
D_left_right_se(d,1)=mean(E_within_se);


movement_se_left=[];
movement_se_right=[];
movement_data_left=[];
movement_data_right=[];
movement_new1=[];
movement_new2=[];
trial_peak1=[];
trial_peak2=[];
end

%% across_session的欧氏距离
D1_across=pdist(movement_left_mean,'euclidean');
Z1=squareform(D1_across);
for i=1:size(Z1,1)-1
D_across_left(i,1)=Z1(i,i+1);
end
D2_across=pdist(movement_right_mean,'euclidean');
Z2=squareform(D2_across);
for i=1:size(Z2,1)-1
D_across_right(i,1)=Z2(i,i+1);
end

%% plot
x=1:1:size(D_left,1);
figure(1)
plot(x,D_left,'r');
hold on;
plot(x,D_right,'b');
hold on;
plot(x,D_left_right,'k');
figure(2)
plot(x,D_left_se,'r');
hold on;
plot(x,D_right_se,'b');
hold on;
plot(x,D_left_right_se,'k');


% figure(2)
% plot(D_across_left,'r');
% hold on;
% plot(D_across_right,'b');
% hold on;
% plot(E_dis,'k');





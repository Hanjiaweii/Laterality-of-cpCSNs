clc;clear;close all

filename='E:\Corticospinal Data\p19';
days_marker=[14];


for d=1:size(days_marker,2)
%% data input
load([filename,'\','neuron_LI_new_',num2str(days_marker(1,d))]);
if  days_marker(1,d)<10
filename1=['E:\Corticospinal Data\p19\Left\d0',num2str(days_marker(1,d)),'\'];
filename2=['E:\Corticospinal Data\p19\Right\d0',num2str(days_marker(1,d)),'\'];
end
if  days_marker(1,d)>10
filename1=['E:\Corticospinal Data\p19\Left\d',num2str(days_marker(1,d)),'\'];
filename2=['E:\Corticospinal Data\p19\Right\d',num2str(days_marker(1,d)),'\'];    
end
pre=0;
post=59;
load([filename1,'movement_se.mat']);
% load([filename1,'movement_epoch_select.mat']);
% load([filename1,'calcium_event.mat']);
load([filename1,'sigtdf.mat']);
sigt_left=sigtdf;
% sigt_left=calcium_event;
left_frame=size(sigt_left,2);
movement_left=movement_se;
% movement_left=movement_epoch_select;
load([filename2,'movement_se.mat']);
load([filename2,'movement_epoch_select.mat']);
% load([filename2,'calcium_event.mat']);
load([filename2,'sigtdf.mat']);
sigt_right=sigtdf;
% sigt_right=calcium_event;
movement_right=movement_se;
% movement_right=movement_epoch_select;


%% Normalize
sigt=[sigt_left,sigt_right];
for neu=1:size(sigt,1)
sigt(neu,:)=normalize(sigt(neu,:));
end
sigt_after_left=sigt(:,1:left_frame);
sigt_after_right=sigt(:,left_frame+1:end);

for neu=1:size(sigt,1)
[frames amplitudes] = AP_trace_peak(sigt(neu,:));
peak_frames{1,neu}=frames;
peak_amplitudes{1,neu}=amplitudes;
end
for neu=1:size(sigt,1)
sigt_before=sigt(neu,:);
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
event_segment=sigt_before(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_frames{1,neu}{1,1}(1,peak_num)+20);
peak_pos=find(event_segment==max(event_segment));
peak_end_frames{1,neu}(1,peak_num)=peak_frames{1,neu}{1,1}(1,peak_num)+peak_pos;
end
else
peak_end_frames{1,neu}=[];
end
end
for neu=1:size(sigt,1)
sigt_after=zeros(1,size(sigt(neu,:),2));
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
sigt_after(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_end_frames{1,neu}(1,peak_num))=peak_amplitudes{1,neu}{1,1}(1,peak_num);
end
end
calcium_event(neu,:)=sigt_after;
end
calcium_left=calcium_event(:,1:left_frame);
calcium_right=calcium_event(:,left_frame+1:end);





for neu=1:size(calcium_left,1)
for trial=1:size(movement_left,1)
sigt_i{neu,1}(trial,:)=calcium_left(neu,movement_left(trial,1)-pre: movement_left(trial,1)+post);
end
end
for neu=1:size(calcium_right,1)
for trial=1:size(movement_right,1)
sigt_c{neu,1}(trial,:)=calcium_right(neu,movement_right(trial,1)-pre: movement_right(trial,1)+post);
end
end

for neu=1:size(sigt_i,1)
sigt_i_mean(neu,:)=mean(sigt_i{neu,1});
end

for neu=1:size(sigt_c,1)
sigt_c_mean(neu,:)=mean(sigt_c{neu,1});
end


%% 按不同类别的神经元在同对侧运动时的发放整理数据
con1_pos=find(neuron_LI==-1);
con2_pos=find(neuron_LI==1);
pos3=find(neuron_LI<0);
con3_pos=setdiff(pos3,con1_pos);
pos4=find(neuron_LI>0);
con4_pos=setdiff(pos4,con2_pos);
neu_class={con1_pos,con2_pos,con3_pos,con4_pos};

for neu_type=1:4
sigt_i_all=sigt_i_mean(neu_class{1,neu_type},:);
sigt_c_all=sigt_c_mean(neu_class{1,neu_type},:);
for i=1:size(sigt_i_all,1)
for j=1:size(sigt_i_all,2)
 if sigt_i_all(i,j)>0
 sigt_i_all(i,j)=1;
 end
  if sigt_c_all(i,j)>0
 sigt_c_all(i,j)=1;
  end
end
end
length=6;
gap_num=60/length;
for i=1:gap_num
 gap=(i-1)*length+1:i*length;
 sigt_i_p(1,i)=mean(sum(sigt_i_all(:,gap))/size(sigt_i_all,1));
 sigt_c_p(1,i)=mean(sum(sigt_c_all(:,gap))/size(sigt_c_all,1));
end
sigt_i_p_all(neu_type,:)=sigt_i_p;
sigt_c_p_all(neu_type,:)=sigt_c_p;
sigt_i_all=[];
sigt_c_all=[];
 sigt_i_p=[];
  sigt_c_p=[];
 figure(neu_type)
  subplot(121)
  bar(sigt_i_p_all(neu_type,:));
  ylim([0,1]);
    subplot(122)
  bar(sigt_c_p_all(neu_type,:));
  ylim([0,1]);
  
end






% filename_new=[filename,'\session',num2str(days_marker(1,d))];
% folder1=[filename_new,'\ipsi-preferring'];
% folder2=[filename_new,'\contra-preferring'];
% folder3=[filename_new,'\bilateral-preferring-ipsi'];
% folder4=[filename_new,'\bilateral-preferring-contra'];
% folder={folder1,folder2,folder3,folder4};
% for type=4 %1:size(neu_class,2) %%%%%%%%%%
% new_folder=folder{1,type};
% mkdir(new_folder);
% for neu=1:size(neu_class{1,type},1)
% figure(neu)
% subplot(221)
%  x=-29:1:60;
% for trial=1:size(movement_left,1)
% plot(x,mean_left,'b');
% hold on;
% end
% % xlim([-29 60]);
% % shadedErrorBar(x,mean_left,std_left,'-b');
% % ylim([0,1]);
% subplot(222)
% for trial=1:size(movement_right,1)
% plot(x,mean_right,'r');
% hold on;
% end
% % xlim([-29 60]);
% % shadedErrorBar(x,mean_right,std_right,'-r');
% % ylim([0,1]);
% subplot(223)
% imagesc(sigt_i{neu_class{1,type}(neu,1),1});
% colorbar;
% caxis([0,1]);
% axis off;
% title(['Neuron ',num2str(neu_class{1,type}(neu,1))]);
% 
% subplot(224)
% imagesc(sigt_c{neu_class{1,type}(neu,1),1});
% colorbar;
% caxis([0,1]);
% axis off;
% title(['Neuron ',num2str(neu_class{1,type}(neu,1))]);
% print(neu,'-dpng',[new_folder,'\Neuron',num2str(neu_class{1,type}(neu,1))],'-r600');
% 
% 
% end 
% close all;
% end

% for type=1:size(neu_class,2)
% 
% for neu=1:size(neu_class{1,type},1)
% X=sigt_i{neu_class{1,type}(neu,1),1};
% for i=1:size(X,1)
% X(i,:)=normalize(X(i,:));
% end
% ips_mean(neu,:)=mean(double(X));
% ips_std(neu,:)=std(double(X));
% Y=sigt_c{neu_class{1,type}(neu,1),1};
% for i=1:size(Y,1)
% Y(i,:)=normalize(Y(i,:));
% end
% con_mean(neu,:)=mean(double(Y));
% con_std(neu,:)=std(double(Y));
%  end
% mean_value{1,type}=ips_mean;
% mean_value{2,type}=con_mean;
% std_value{1,type}=ips_std;
% std_value{2,type}=con_std;
% ips_mean=[];
% ips_std=[];
% con_mean=[];
% con_std=[];
% end
% filename_new=[filename,'\session',num2str(days_marker(1,d))];
% folder1=[filename_new,'\ipsi-preferring'];
% folder2=[filename_new,'\contra-preferring'];
% folder3=[filename_new,'\bilateral-preferring-ipsi'];
% folder4=[filename_new,'\bilateral-preferring-contra'];
% folder={folder1,folder2,folder3,folder4};
% for type=1:size(mean_value,2)
% new_folder=folder{1,type};
% mkdir(new_folder);
% for neu=1:size(mean_value{1,type},1)
%  figure(neu)
%  subplot(311)
% x=-29:1:30;
% shadedErrorBar(x,mean_left,std_left,'-b');
% ylim([0,1]);
% subplot(312)
% shadedErrorBar(x,mean_right,std_right,'-r');
% ylim([0,1]);
% subplot(313)
% shadedErrorBar(x,mean_value{1,type}(neu,:),std_value{1,type}(neu,:),'-b');
% hold on;
% shadedErrorBar(x,mean_value{2,type}(neu,:),std_value{2,type}(neu,:),'-r');
% title(['Neuron ',num2str(neu_class{1,type}(neu,1))]);
% ylim([0,1]);
% print(neu,'-dpng',[new_folder,'\Neuron',num2str(neu_class{1,type}(neu,1))],'-r600');
% end
% close all;
% end

end
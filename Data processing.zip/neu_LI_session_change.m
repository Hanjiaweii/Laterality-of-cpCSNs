clc;clear;close all
filename='H:\p17\';
days_marker=[26];
for d=1:size(days_marker,2)
%% data input
if  days_marker(1,d)<10
filename1=['H:\p17\Left\d0',num2str(days_marker(1,d)),'\'];
filename2=['H:\p17\Right\d0',num2str(days_marker(1,d)),'\'];
end
if  days_marker(1,d)>10
filename1=['H:\p17\Left\d',num2str(days_marker(1,d)),'\'];
filename2=['H:\p17\Right\d',num2str(days_marker(1,d)),'\'];    
end
pre=0;
post=59;
load([filename1,'movement_se.mat']);
load([filename1,'sigtdf.mat']);
sigt_left=sigtdf;
left_frame=size(sigt_left,2);
movement_left=movement_se;
load([filename2,'movement_se.mat']);
load([filename2,'sigtdf.mat']);
sigt_right=sigtdf;
movement_right=movement_se;
load([filename,'\','neuron_LI_new_',num2str(days_marker(1,d))]);
neuron_LI_final=neuron_LI;

%% Normalize && Detect calcium events
sigt=[sigt_left,sigt_right];
for neu=1:size(sigt,1)
sigt(neu,:)=normalize(sigt(neu,:));
end


% calcium detect
for neu=1:size(sigt,1)
[frames amplitudes] = AP_trace_peak(sigt(neu,:));
peak_frames{1,neu}=frames;
peak_amplitudes{1,neu}=amplitudes;
end
for neu=1:size(sigt,1)
sigt_before=sigt(neu,:);
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
event_segment=sigt_before(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_frames{1,neu}{1,1}(1,peak_num)+20);
peak_pos=find(event_segment==max(event_segment));
peak_end_frames{1,neu}(1,peak_num)=peak_frames{1,neu}{1,1}(1,peak_num)+peak_pos;
end
else
peak_end_frames{1,neu}=[];
end
end
for neu=1:size(sigt,1)
sigt_after=zeros(1,size(sigt(neu,:),2));
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
sigt_after(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_end_frames{1,neu}(1,peak_num))=peak_amplitudes{1,neu}{1,1}(1,peak_num);
end
end
calcium_event(neu,:)=sigt_after;
end

calcium_left=calcium_event(:,1:left_frame);
calcium_right=calcium_event(:,left_frame+1:end);


%% Task-related calcium events (early and late trials)
trial_num=15;%% 如果报错，把数值改小，说明不够15个trial
movement_left_new=sortrows(movement_left,1);
movement_left_early=movement_left_new(1:trial_num,:);
movement_left_late=movement_left_new(size(movement_left,1)-trial_num+1:size(movement_left,1),:);
movement_right_new=sortrows(movement_right,1);
movement_right_early=movement_right_new(1:trial_num,:);
movement_right_late=movement_right_new(size(movement_right,1)-trial_num+1:size(movement_right,1),:);

for neu=1:size(calcium_left,1)
 XX1=[];
for trial=1:size(movement_left_early,1)
XX1=[XX1, calcium_left(neu,movement_left_early(trial,1)-pre: movement_left_early(trial,1)+post)];
end
sigt_i_early(neu,:)=XX1;
end

for neu=1:size(calcium_left,1)
 XX2=[];
for trial=1:size(movement_left_late,1)
XX2=[XX2, calcium_left(neu,movement_left_late(trial,1)-pre: movement_left_late(trial,1)+post)];
end
sigt_i_late(neu,:)=XX2;
end

for neu=1:size(calcium_right,1)
YY1=[];
for trial=1:size(movement_right_early,1)
YY1=[YY1, calcium_right(neu,movement_right_early(trial,1)-pre: movement_right_early(trial,1)+post)];
end
sigt_c_early(neu,:)=YY1;
end

for neu=1:size(calcium_right,1)
YY2=[];
for trial=1:size(movement_right_late,1)
YY2=[YY2, calcium_right(neu,movement_right_late(trial,1)-pre: movement_right_late(trial,1)+post)];
end
sigt_c_late(neu,:)=YY2;
end

%%  Laterality index
neu_marker_zero=ones(size(calcium_left,1),1);
for neu=1:size(calcium_left,1)
left_count=find(diff(calcium_left(neu,:))>0);
right_count=find(diff(calcium_right(neu,:))>0);
if size(left_count,2)<5&&size(right_count,2)<5
neu_marker_zero(neu,1)=0;
end
end


neuron_LI=zeros(size(sigt,1),2);
for neu=1:size(sigt,1)
i=mean(sigt_i_early(neu,:));
c=mean(sigt_c_early(neu,:));
 if c>0&&i==0
 neuron_LI(neu,1)=1;
 end
 if c==0&&i>0
 neuron_LI(neu,1)=-1;
 end
 if c>0&&i>0
 neuron_LI(neu,1)=(c-i)/(c+i);
 end
end

 
 for neu=1:size(sigt,1)
i=mean(sigt_i_late(neu,:));
c=mean(sigt_c_late(neu,:));
 if c>0&&i==0
 neuron_LI(neu,2)=1;
 end
 if c==0&&i>0
 neuron_LI(neu,2)=-1;
 end
 if c>0&&i>0
 neuron_LI(neu,2)=(c-i)/(c+i);
 end
 end
 
 for neu=1:size(neu_marker_zero,1)
if neu_marker_zero(neu,1)==0
neuron_LI(neu,:)=0;
end
 end
 
neuron_LI(:,3)=neuron_LI_final;

 %%计算LI稳定的百分比
 neuron_LI_type=neuron_LI*0;
 for i=1:size(neuron_LI,1)
 for j=1:size(neuron_LI,2)
if neuron_LI(i,j)==-1
    neuron_LI_type(i,j)=1;
end
if neuron_LI(i,j)==1
    neuron_LI_type(i,j)=2;
end
if abs(neuron_LI(i,j))>0&&abs(neuron_LI(i,j))<1
    neuron_LI_type(i,j)=3;
 end
 end
 end
 
 
 LI_s=neuron_LI_type(:,1)+neuron_LI_type(:,2);
 LI_s_pos=find( LI_s>0);
 LI_change= neuron_LI_type(:,1)- neuron_LI_type(:,2);
 stable_pos=find(LI_change==0);
 stable_pos_minus=intersect(LI_s_pos,stable_pos);
 stable_index=size(stable_pos_minus,1)/size(LI_s_pos,1)
 
 
 
 
 %% 计算集群LI的变化值
 A=neuron_LI(:,1);
 LI_early=mean(A(A~=0))
 B=neuron_LI(:,2);
 LI_late=mean(B(B~=0))
 C=neuron_LI(:,3);
 LI_session=mean(C(C~=0))
 
end

clc;clear;close all
filename='H:\p01\';
days_marker=[3];
for d=1:size(days_marker,2)
%% data input
if  days_marker(1,d)<10
filename1=['H:\p01\Left\d0',num2str(days_marker(1,d)),'\'];
filename2=['H:\p01\Right\d0',num2str(days_marker(1,d)),'\'];
end
if  days_marker(1,d)>10
filename1=['H:\p01\Left\d',num2str(days_marker(1,d)),'\'];
filename2=['H:\p01\Right\d',num2str(days_marker(1,d)),'\'];    
end
pre=0;
post=59;
load([filename1,'movement_se.mat']);
load([filename1,'sigtdf.mat']);
sigt_left=sigtdf;
left_frame=size(sigt_left,2);
movement_left=movement_se;
load([filename2,'movement_se.mat']);
load([filename2,'sigtdf.mat']);
sigt_right=sigtdf;
movement_right=movement_se;


%% Normalize && Detect calcium events
sigt=[sigt_left,sigt_right];
for neu=1:size(sigt,1)
sigt(neu,:)=normalize(sigt(neu,:));
end


% calcium detect
for neu=1:size(sigt,1)
[frames amplitudes] = AP_trace_peak(sigt(neu,:));
peak_frames{1,neu}=frames;
peak_amplitudes{1,neu}=amplitudes;
end
for neu=1:size(sigt,1)
sigt_before=sigt(neu,:);
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
event_segment=sigt_before(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_frames{1,neu}{1,1}(1,peak_num)+20);
peak_pos=find(event_segment==max(event_segment));
peak_end_frames{1,neu}(1,peak_num)=peak_frames{1,neu}{1,1}(1,peak_num)+peak_pos;
end
else
peak_end_frames{1,neu}=[];
end
end
for neu=1:size(sigt,1)
sigt_after=zeros(1,size(sigt(neu,:),2));
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
sigt_after(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_end_frames{1,neu}(1,peak_num))=peak_amplitudes{1,neu}{1,1}(1,peak_num);
end
end
calcium_event(neu,:)=sigt_after;
end

calcium_left=calcium_event(:,1:left_frame);
calcium_right=calcium_event(:,left_frame+1:end);


%% Task-related calcium events
for neu=1:size(calcium_left,1)
 XX=[];
for trial=1:size(movement_left,1)
XX=[XX, calcium_left(neu,movement_left(trial,1)-pre: movement_left(trial,1)+post)];
end
sigt_i(neu,:)=XX;
end
for neu=1:size(calcium_right,1)
YY=[];
for trial=1:size(movement_right,1)
YY=[YY, calcium_right(neu,movement_right(trial,1)-pre: movement_right(trial,1)+post)];
end
sigt_c(neu,:)=YY;
end

%%  Laterality index
neuron_LI=zeros(size(sigt_i,1),1);
for neu=1:size(sigt_c,1)
i=mean(sigt_i(neu,:));
c=mean(sigt_c(neu,:));
 if c>0&&i==0
 neuron_LI(neu,1)=1;
 end
 if c==0&&i>0
 neuron_LI(neu,1)=-1;
 end
 if c>0&&i>0
 neuron_LI(neu,1)=(c-i)/(c+i);
 end
end

%% figure
% figure(d)
% pos=find(abs(neuron_LI)>0);
% neuron_LI_se=neuron_LI(pos);
% [y,x]=hist(neuron_LI_se,1001); 
% y=y/length(neuron_LI_se);   
% X=-1:0.002:1;
% Y=cumsum(y);
% neu_LI_val(d,:)=Y;
% plot(X,Y);
% ylim([0,1]);
save([filename,'\','neuron_LI_',num2str(days_marker(1,d))],'neuron_LI');

%  variables clear
calcium_event=[];sigt_i=[];sigt_c=[]; neuron_LI=[];
peak_frames=[];
peak_amplitudes=[];
peak_end_frames=[];
end

duide clc;clear;close all;
%% 输入所有需要比较的session 的运动数据
days_marker=[4:1:9,11:1:22];
% ,11:1:12,14:1:17,19:1:19,22:1:25,27:1:27];
for day=1:size(days_marker,2)
 if days_marker(1,day)<10
filename=['E:\Corticospinal Data\g19\Right\d0',num2str(days_marker(1,day)),'\'];
 end
 if days_marker(1,day)>=10
filename=['E:\Corticospinal Data\g19\Right\d',num2str(days_marker(1,day)),'\'];
 end
load([filename,'movement_epoch_frames']);
movement_data_all{day,1}=movement_epoch_frames;
end
%% 计算学会的session运动数据的均值
XX=[];
for j=15:18   %比较的session
XX=[XX; movement_data_all{j,1}];
end
learned_mean=mean(XX);
%% 计算各个session内的运动数据与已经学会的行为学轨迹之间的相关性
for i=1:size(movement_data_all,1)
for j=1:size(movement_data_all{i,1},1)
R=corrcoef(learned_mean,movement_data_all{i,1}(j,:));
r(j,1)=R(1,2);
end
movement_data_correlation{i,1}=r;
r=[];
end
%% 把每个session 内的运动学数据按相关性排序
for i=1:size(movement_data_correlation,1)
movement_data_correlation{i,1}(:,1)=abs(movement_data_correlation{i,1}(:,1));
movement_data_correlation{i,1}(:,2)=1:1:size(movement_data_correlation{i,1},1);
end
for i=1:size(movement_data_correlation,1)
movement_data_correlation_new{i,1}=sortrows(movement_data_correlation{i,1},1);
end
filename='E:\Corticospinal Data\g19\Right\';
save([filename,'movement_data_correlation_frame'],'movement_data_correlation');
save([filename,'movement_data_all_frame'],'movement_data_all');

%%  分阶段统计相关性与对应的运动轨迹
times1=1:1:4;%阶段1
YY=[]; ZZ=[];MM=[];
for i=1:size(times1,2)
 YY=[YY;movement_data_all{times1(1,i),1}];
 ZZ=[ZZ;movement_data_correlation{times1(1,i),1}(:,1)];
 MM=[MM;ones(size(movement_data_correlation{times1(1,i),1},1),1)*times1(1,i)];
 movement_times_all{1,1}=YY;
 movement_times_correlation{1,1}=[ZZ,MM];
end

times2=8:1:11;%阶段2
YY=[]; ZZ=[];MM=[];
for i=1:size(times2,2)
 YY=[YY;movement_data_all{times2(1,i),1}];
 ZZ=[ZZ;movement_data_correlation{times2(1,i),1}(:,1)];
 MM=[MM;ones(size(movement_data_correlation{times2(1,i),1},1),1)*times2(1,i)];
 movement_times_all{2,1}=YY;
 movement_times_correlation{2,1}=[ZZ,MM];
end

times3=15:1:18;%阶段3
YY=[]; ZZ=[];MM=[];
for i=1:size(times3,2)
 YY=[YY;movement_data_all{times3(1,i),1}];
 ZZ=[ZZ;movement_data_correlation{times3(1,i),1}(:,1)];
 MM=[MM;ones(size(movement_data_correlation{times3(1,i),1},1),1)*times3(1,i)];
 movement_times_all{3,1}=YY;
 movement_times_correlation{3,1}=[ZZ,MM];
end

%% 画出不同阶段内不同相关性范围内的运动轨迹
for i=1:size(movement_times_all,1)
movement_times_all{i,1}(:,91:92)=movement_times_correlation{i,1};
end
for i=1:size(movement_times_all,1)
movement_times_correlation_frame{i,1}=sortrows(movement_times_all{i,1},91);
end
save([filename,'movement_times_correlation_frame'],'movement_times_correlation_frame');

for i=1:size(movement_times_all,1)
figure(i)
range1=1:floor(size(movement_times_all{i,1},1)*0.2);
range2=floor(size(movement_times_all{i,1},1)*0.4):floor(size(movement_times_all{i,1},1)*0.6);    
range3=floor(size(movement_times_all{i,1},1)*0.8):floor(size(movement_times_all{i,1},1)*1); 
subplot(131)
for j=1:size(range1,2)
plot(1:1:90,movement_times_correlation_frame{i,1}(range1(1,j),1:end-2));
hold on;
end
subtitle('0-20%');
set(gca,'xtick',0:30:90);
label={'-30','0','30','60'};
set(gca,'xticklabel',label);
subplot(132)
for j=1:size(range2,2)
plot(1:1:90,movement_times_correlation_frame{i,1}(range2(1,j),1:end-2));
hold on;
end
subtitle('40%-60%');
set(gca,'xtick',0:30:90);
label={'-30','0','30','60'};
set(gca,'xticklabel',label);
subplot(133)
for j=1:size(range3,2)
plot(1:1:90,movement_times_correlation_frame{i,1}(range3(1,j),1:end-2));
hold on;
end
subtitle('80%-100%');
set(gca,'xtick',0:30:90);
label={'-30','0','30','60'};
set(gca,'xticklabel',label);
sgtitle(['Section',num2str(i)]);
print(i,'-dpng',[filename,'correletion_with_learned_movement_frame',num2str(i)],'-r600');
end
%% 统计不同阶段内不同相关性范围的分布
times={times1,times2,times3};
for i=1:size(times,2)
 for j=1:size(times{1,i},2)
 trial_dis(i,j)=size(movement_data_all{times{1,i}(1,j),1},1);
 end
end


for i=1:size(movement_times_all,1)
range1=1:floor(size(movement_times_all{i,1},1)*0.2);
range2=floor(size(movement_times_all{i,1},1)*0.4):floor(size(movement_times_all{i,1},1)*0.6);    
range3=floor(size(movement_times_all{i,1},1)*0.8):floor(size(movement_times_all{i,1},1)*1); 
correlation_dis{i,1}=movement_times_correlation_frame{i,1}(range1,end);
correlation_dis{i,2}=movement_times_correlation_frame{i,1}(range2,end);
correlation_dis{i,3}=movement_times_correlation_frame{i,1}(range3,end);
end

for m=1:size(correlation_dis,1)
time=times{1,m};    
for n=1:size(correlation_dis,2)
for k=1:size(time,2)
num=find(correlation_dis{m,n}==time(1,k));
% dis_num(n,k)=size(num,1)/size(correlation_dis{m,n},1);
dis_num(n,k)=size(num,1);
end
end
dis_num_all{1,m}=dis_num;
end
 for i=1:size(dis_num_all,2)
 for j=1:size(dis_num_all{1,i},1)
 dis_num_all_av{1,i}(j,:)=dis_num_all{1,i}(j,:)./trial_dis(i,:);
 end
 end
 for i=1:size(dis_num_all_av,2)
 for j=1:size(dis_num_all_av{1,i},1)
 dis_num_all_av{1,i}(j,:)=dis_num_all_av{1,i}(j,:)/sum(dis_num_all_av{1,i}(j,:));
 end
 end

save([filename,'correlation_distribution'],'dis_num_all_av');

figure(4)
subplot(131)
bar(dis_num_all_av{1, 1},'stacked','DisplayName','dis_num_all{1, 1}')
subtitle('section1');
ylim([0 1]);
label={'0-20%','40%-60%','80%-100%'};
set(gca,'xticklabel',label);
subplot(132)
bar(dis_num_all_av{1, 2},'stacked','DisplayName','dis_num_all{1, 2}')
subtitle('section2');
ylim([0 1]);
label={'0-20%','40%-60%','80%-100%'};
set(gca,'xticklabel',label);
subplot(133)
bar(dis_num_all_av{1, 3},'stacked','DisplayName','dis_num_all{1, 3}')
subtitle('section3');
label={'0-20%','40%-60%','80%-100%'};
ylim([0 1]);
set(gca,'xticklabel',label);






% %% 画出每个session内不同相关性范围内的运动轨迹
% for i=1:size(movement_data_correlation_new,1)
% figure(i)
% range1=1:floor(size(movement_data_correlation_new{i,1},1)*0.2);
% range2=floor(size(movement_data_correlation_new{i,1},1)*0.4):floor(size(movement_data_correlation_new{i,1},1)*0.6);    
% range3=floor(size(movement_data_correlation_new{i,1},1)*0.8):floor(size(movement_data_correlation_new{i,1},1)*1); 
% subplot(131)
% for j=1:size(range1,2)
% plot(1:1:90,movement_data_all{i,1}(movement_data_correlation_new{i,1}(range1(1,j),2),:));
% hold on;
% end
% subtitle('0-20%');
% set(gca,'xtick',1:30:91);
% label={'-30','0','30','60'};
% set(gca,'xticklabel',label);
% subplot(132)
% for j=1:size(range2,2)
% plot(1:1:90,movement_data_all{i,1}(movement_data_correlation_new{i,1}(range2(1,j),2),:));
% hold on;
% end
% subtitle('40%-60%');
% set(gca,'xtick',1:30:91);
% label={'-30','0','30','60'};
% set(gca,'xticklabel',label);
% subplot(133)
% for j=1:size(range3,2)
% plot(1:1:90,movement_data_all{i,1}(movement_data_correlation_new{i,1}(range3(1,j),2),:));
% hold on;
% end
% subtitle('80%-100%');
% set(gca,'xtick',1:30:91);
% label={'-30','0','30','60'};
% set(gca,'xticklabel',label);
% sgtitle(['Session',num2str(i)]);
% if i<10
% filename=['H:\p01\Left\d0',num2str(i),'\'];
%  end
%  if i>=10
% filename=['H:\p01\Left\d',num2str(i),'\'];
%  end
% print(i,'-dpng',[filename,'correletion_with_learned_movement'],'-r600');
% end    
% close all;    
    

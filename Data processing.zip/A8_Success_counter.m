clear;clc;close all;

%% Data Input
days_marker=[1:1:22];
for i=1:size(days_marker,2)
    if days_marker(1,i)<10
    filename=['H:\p17\Right\d0',num2str(days_marker(1,i)),'\'];
    end
    if days_marker(1,i)>=10
    filename=['H:\p17\Right\d',num2str(days_marker(1,i)),'\'];
    end
    
load([filename,'cue_marker']);

success=find(cue_marker==2);
fail=find(cue_marker==3);

success_num(i,1)=size(find(diff(success)>1),2)+1;
fail_num(i,1)=size(find(diff(fail)>1),2)+1;

rate(i,1)=success_num(i,1)/(fail_num(i,1)+success_num(i,1));
end
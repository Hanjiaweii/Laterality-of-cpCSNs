clear
close all
clc;

%% data input
filename='H:\p07\Left\d01\';%���ݴ��·��
load([filename,'\','movement_epoch_select']);%trial����Ϣ
% load([filename,'\','F_final']);%��������Fֵ
% load([filename,'\','Fall']);
load([filename,'\','sigtdf']);
% load([filename,'\','neu_marker_1']);

% %% ����dF/Fֵ
% neu_num=find(iscell(:,1)==1);
% sigt=F_final(:,neu_num)';
% window_length=450;
% for neu=1:size(sigt,1)
% for t=window_length+1:size(sigt, 2)-window_length
% f0(neu,t)=mean(sigt(neu,t-window_length:t+window_length)); 
% end
% end
% for neu=1:size(sigt, 1)
% f0(neu,1:window_length)=f0(neu,window_length+1);
% f0(neu,size(sigt, 2)-window_length+1:size(sigt, 2))=f0(neu,size(sigt, 2)-window_length);
% end    
% for neu =1:size(sigt, 1)
% for t=1:size(sigt,2)
% sigtdf(neu,t)=(sigt(neu,t)-f0(neu,t))/f0(neu,t);
% end
% end

%% ����trial��ȡ��Ԫ������
pre=0;
post=89;
sigtdf=sigtdf;
for neu=1:size(sigtdf,1)
for trial=1:size(movement_epoch_select,1)
sigt_trial{neu,1}(trial,:)=sigtdf(neu,movement_epoch_select(trial,1)-pre:movement_epoch_select(trial,1)+post);
end
end
for neu=1:size(sigt_trial,1)
sigt_mean(neu,:)=mean(sigt_trial{neu,1});
end
%save([filename,'\','sigt_mean'],'sigt_mean');
% pre=0;
% post=89;
% for neu=1:size(sigtdf,1)
% for trial=1:size(movement_epoch_select,1)
% sigt_trial{neu,1}(trial,:)=normalize(sigtdf(neu,movement_epoch_select(trial,1)-pre:movement_epoch_select(trial,1)+post));
% end
% end
% for neu=1:size(sigt_trial,1)
% sigt_mean(neu,:)=mean(sigt_trial{neu,1});
% end
% save([filename,'\','sigt_mean'],'sigt_mean');

%% ����peak��ʱ�������
for neu=1:size(sigt_mean,1)
pp=find(sigt_mean(neu,:)==max(sigt_mean(neu,:)));
peak(neu,1)=pp(1,1);
end
no=1:1:size(neu_marker,1);
sigt_no=[sigt_mean,neu_num,no',peak];
sigt_no_after=sortrows(sigt_no,pre+post+4);
neu_peak_no=sigt_no_after(:,end-2);
neu_no=sigt_no_after(:,end-1);
for i=1:size(neu_marker,1)
neu_peak_marker(i,1)=neu_marker(neu_no(i,1),1);
end
for i=1:size(neu_peak_marker,1)
 if neu_peak_marker(i,1)==0
  map(i,:)=[1,1,1];
 end
  if neu_peak_marker(i,1)==1
  map(i,:)=[0.75,0.75,0.75];
  end
   if neu_peak_marker(i,1)==2
  map(i,:)=[0.5,0.5,0.5];
  end
    if neu_peak_marker(i,1)==3
  map(i,:)=[0,0,0];
  end
end
y=wrev(map);

%% ��ͼ
figure(1)
imagesc(1:1:pre+post+1,1:1:size(sigt_no_after,1),sigt_no_after(:,1:end-3));
hold on;
line([pre+31 pre+31],[1 size(sigt_no_after,1)],'Color','k','Linewidth',1.5,'Linestyle','--');
set(gca,'xtick',1:30:90);
label={'0','30','60','90'};
set(gca,'xticklabel',label);
xlabel('Frame');ylabel('Sorted Neurons'); 
print(1,'-dpng',[filename,'trial_average_1'],'-r600');
figure(2)
colormap(y);
colorbar('YTick', 1:1:3, 'YTickLabel', {' 1', '2', '3'});
print(2,'-dpng',[filename,'neu_marker_1'],'-r600');
save([filename,'\','neu_peak_no_1'],'neu_peak_no');
save([filename,'\','neu_peak_marker_1'],'neu_peak_marker');
clear;clc;close all;

%% 输入需要计算的session时间
days_marker=1:1:1;
for i=1:size(days_marker,2)
 if days_marker(1,i)<10
filename=['H:\p16\Right\d0',num2str(days_marker(1,i)),'\'];
 end
 if days_marker(1,i)>=10
filename=['H:\p16\Right\d',num2str(days_marker(1,i)),'\'];
 end
load([filename,'\','F_final']);%处理过的F值
load([filename,'\','Fall']);
%% 计算DF/F
neu_num=find(iscell(:,1)==1);
sigt=F_final(:,neu_num)';
window_length=450;
for neu=1:size(sigt,1)
for t=window_length+1:size(sigt, 2)-window_length
f0(neu,t)=mean(sigt(neu,t-window_length:t+window_length)); 
end
end
for neu=1:size(sigt, 1)
f0(neu,1:window_length)=f0(neu,window_length+1);
f0(neu,size(sigt, 2)-window_length+1:size(sigt, 2))=f0(neu,size(sigt, 2)-window_length);
end    
for neu =1:size(sigt, 1)
for t=1:size(sigt,2)
sigtdf(neu,t)=(sigt(neu,t)-f0(neu,t))/f0(neu,t);
end
end
save([filename,'\','sigtdf'],'sigtdf');
end

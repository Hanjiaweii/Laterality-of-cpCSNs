clear
close all
clc;

%% Data Input

days_marker=[17,19:1:22];
for i=1:size(days_marker,2)
    if days_marker(1,i)<10
    filename=['E:\Corticospinal Data\p21\Left\d0',num2str(days_marker(1,i)),'\'];
    end
    if days_marker(1,i)>=10
    filename=['E:\Corticospinal Data\p21\Left\d',num2str(days_marker(1,i)),'\'];
    end
    
load([filename,'\','movement_epoch_select']); %trial的信息
load([filename,'\','sigtdf']);
load([filename,'\','select_trial_left']);

select_trial=select_trial_left; %需修改左右侧

%% 按照trial提取神经元的数据
pre=0;
post=89;
sigtdf=sigtdf;
for neu=1:size(sigtdf,1)
for trial=1:size(movement_epoch_select,1)
sigt_trial{neu,1}(trial,:)=sigtdf(neu,movement_epoch_select(trial,1)-pre:movement_epoch_select(trial,1)+post);
end
end
for neu=1:size(sigtdf,1)
for trial=1:size(select_trial,1)
sigt_trial_select{neu,1}(trial,:)=sigtdf(neu,movement_epoch_select(select_trial(trial,1),1)-pre:movement_epoch_select(select_trial(trial,1),1)+post);
end
end


for neu=1:size(sigt_trial,1)
sigt_mean(neu,:)=mean(sigt_trial{neu,1});
end

for neu=1:size(sigt_trial_select,1)
sigt_mean_select(neu,:)=mean(sigt_trial_select{neu,1});
end


save([filename,'\','sigt_mean'],'sigt_mean');
save([filename,'\','sigt_mean_select'],'sigt_mean_select');
sigt_mean=[];
sigt_mean_select=[];
end
clc; clear; close all;
filename='E:\Corticospinal Data\p19';

load([filename,'\Left\d15\angle_downsample.mat']);
load([filename,'\Left\d15\movement_epoch_select.mat'])
load([filename,'\Left\d15\sigtdf.mat']);
angle_left=angle_downsample;
movement_left=movement_epoch_select;
sigt_left=sigtdf;
load([filename,'\Right\d15\angle_downsample.mat']);
load([filename,'\Right\d15\movement_epoch_select.mat'])
load([filename,'\Right\d15\sigtdf.mat']);
angle_right=angle_downsample;
movement_right=movement_epoch_select;
sigt_right=sigtdf;
load([filename,'\neuron_LI_new_15.mat']);
sigt=[sigt_left,sigt_right];
angle=[normalize(angle_left);normalize(angle_right)];
left_frame=size(angle_left,1);
movement=[movement_left;movement_right+left_frame];
for neu=1:size(sigt,1)
sigt(neu,:)=smooth(sigt(neu,:));
sigt(neu,:)=normalize(sigt(neu,:));
end
% % neu_p1=find(neuron_LI==-1);
% % population=mean(sigtdf(neu_p1,:));
neu_num=size(sigt,1);
duration1=6000:7500;%%%%%%%修改帧
duration2=(5500:8000)+left_frame;
duration_all=[duration1, duration2];
figure(1)
for i=1:size(sigt,1) %%%%神经元数目修改
if neuron_LI(i,1)==-1
plot(sigt(i,duration_all)+i,'r');
end
if neuron_LI(i,1)==1
plot(sigt(i,duration_all)+i,'b');
end
if neuron_LI(i,1)>-1&&neuron_LI(i,1)<0
plot(sigt(i,duration_all)+i,'y');
end
if neuron_LI(i,1)>0&&neuron_LI(i,1)<1
plot(sigt(i,duration_all)+i,'g');
end
if neuron_LI(i,1)==0
plot(sigt(i,duration_all)+i,'k');
end
hold on
end
plot(normalize(angle(duration_all))+i+1,'k');
% plot(normalize(population(duration)+i+2,'r');



%% 筛选运动片段标注
pos1=find(movement(:,1)>duration1(1,1));
pos2=find(movement(:,1)<duration1(1,end));
pos3=find(movement(:,1)>duration2(1,1));
pos4=find(movement(:,1)<duration2(1,end));
pos11=intersect(pos1,pos2);
push_pos1=movement(pos11,:)-duration1(1,1);
pos12=intersect(pos3,pos4);
push_pos2=movement(pos12,:)-duration2(1,1)+duration1(1,end)-duration1(1,1);
push_pos=[push_pos1;push_pos2];
for i=1:size(push_pos,1)
  line([push_pos(i,1) push_pos(i,1)],[0 neu_num+5],'color','k');
    line([push_pos(i,2) push_pos(i,2)],[0 neu_num+5],'color','k');
end


figure(2)
neu_no=[6,24,45,7,13,2,46,20,38,43];%%%%%%%神经元序号
for i=1:size(neu_no,2)
if neuron_LI(neu_no(1,i),1)==-1
plot(sigt(neu_no(1,i),duration_all)+i,'r');
end
if neuron_LI(neu_no(1,i),1)==1
plot(sigt(neu_no(1,i),duration_all)+i,'b');
end
if neuron_LI(neu_no(1,i),1)>-1&&neuron_LI(neu_no(1,i),1)<0
plot(sigt(neu_no(1,i),duration_all)+i,'y');
end
if neuron_LI(neu_no(1,i),1)>0&&neuron_LI(neu_no(1,i),1)<1
plot(sigt(neu_no(1,i),duration_all)+i,'g');
end
if neuron_LI(neu_no(1,i),1)==0
plot(sigt(neu_no(1,i),duration_all)+i,'k');
end
hold on
end
plot(normalize(angle(duration_all))+i+1,'k');
pos1=find(movement(:,1)>duration1(1,1));
pos2=find(movement(:,1)<duration1(1,end));
pos3=find(movement(:,1)>duration2(1,1));
pos4=find(movement(:,1)<duration2(1,end));
pos11=intersect(pos1,pos2);
push_pos1=movement(pos11,:)-duration1(1,1);
pos12=intersect(pos3,pos4);
push_pos2=movement(pos12,:)-duration2(1,1)+duration1(1,end)-duration1(1,1);
push_pos=[push_pos1;push_pos2];


for i=1:size(push_pos,1)
  line([push_pos(i,1) push_pos(i,1)],[0 size(neu_no,2)+2],'color','k');
    line([push_pos(i,2) push_pos(i,2)],[0 size(neu_no,2)+2],'color','k');
end

%% trial 平均画图
% for i=1:size(sigtdf,1)
%    for j=1:size(push_pos,1)
% neu_trial{1,i}(j,:)=calcium_event(i,push_pos(j,1)+8000:push_pos(j,2)+8000);
%     end
% end
% 
% for i=1:size(sigtdf,1)
%     neu_mean(i,:)=mean(neu_trial{1,i});
% end
% pos_neu=find(abs(neuron_LI)>0);
% imagesc(neu_mean(pos_neu,:));



clear;clc;close all;

%% Data Input
days_marker=[3];
for i=1:size(days_marker,2)
    filename='H:\p01\';
    if days_marker(1,i)<10
    filename1=[filename,'Left\d0',num2str(days_marker(1,i)),'\'];
    filename2=[filename,'Right\d0',num2str(days_marker(1,i)),'\'];
    end
    if days_marker(1,i)>=10
   filename1=[filename,'Left\d',num2str(days_marker(1,i)),'\'];
   filename2=[filename,'Right\d',num2str(days_marker(1,i)),'\'];
    end
load([filename,'neuron_LI_',num2str(days_marker(1,i))]);
load([filename1,'calcium_event']);
calcium_left=calcium_event;
load([filename2,'calcium_event']);
calcium_right=calcium_event;
neu_marker_zero=ones(size(calcium_left,1),1);
%% 在整个任务期间发放小于5次的神经元，定义为静息，marker为0
for neu=1:size(calcium_left,1)
left_count=find(diff(calcium_left(neu,:))>0);
right_count=find(diff(calcium_right(neu,:))>0);
if size(left_count,2)<5&&size(right_count,2)<5
neu_marker_zero(neu,1)=0;
end
end
for neu=1:size(neu_marker_zero,1)
if neu_marker_zero(neu,1)==0
neuron_LI(neu,1)=0;
end
end
save([filename,'\','neuron_LI_new_',num2str(days_marker(1,i))],'neuron_LI');

figure(i) %累计权重
pos=find(abs(neuron_LI)>0);
neuron_LI_se=neuron_LI(pos);
[y,x]=hist(neuron_LI_se,1001); 
y=y/length(neuron_LI_se);   
X=-1:0.002:1;
Y=cumsum(y);
neu_LI_val(days_marker,:)=Y;
plot(X,Y);
ylim([0,1]);
end

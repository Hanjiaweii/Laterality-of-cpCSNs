clear
close all
clc;
%% data input
filename='H:\p16\03_D17-20_New\suite2p\plane0\';%数据存放路径
load([filename,'\','Fall']);
neu_pos=find(iscell(:,1)==1);
F_value=F(neu_pos,:);

%% 计算各个session内两两神经信号之间的相似性
frames=18223;
sessions=size(F_value,2)/frames;
for i=1:sessions
k=0;
for m=1:size(F_value,1)-1
    for n=m+1:size(F_value,1)
k=k+1;
R=corrcoef(F_value(m,(i-1)*frames+1:i*frames),F_value(n,(i-1)*frames+1:i*frames));
r(k,i)=R(1,2);
label_r(k,1)=m;
label_r(k,2)=n;
    end
end
end
%% 取所有session相关性的最大值
for i=1:size(r,1)
cc_abs=abs(r(i,:));
x=find(cc_abs==max(cc_abs));
max_cc(i,1)=r(i,x);
end


%% 统计分布情况
for  j=1:15
    q=0;
for i=1:size(max_cc,1)  
if (max_cc(i,1)<=j*0.1-0.5)&& (max_cc(i,1)>(j-1)*0.1-0.5)
q=q+1;
end
end
cc_dix(j,1)=q/k;
end

figure(1)
bar(cc_dix);
ylabel('Percentage');
 xtick=1:1:15;
 xlabel=-0.4:0.1:1;
 set(gca,'XTicklabel',xlabel);
 print(1,'-dpng',[filename,'r_distribution'],'-r600');
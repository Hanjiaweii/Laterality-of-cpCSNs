clear
close all
clc;

%% Data Input

days_marker=[2];
for i=1:size(days_marker,2)
    if days_marker(1,i)<10
    filename1=['H:\p17\Left\d0',num2str(days_marker(1,i)),'\'];
    end
    if days_marker(1,i)>=10
    filename1=['H:\p17\Left\d',num2str(days_marker(1,i)),'\'];
    end
    
    if days_marker(1,i)<10
    filename2=['H:\p17\Right\d0',num2str(days_marker(1,i)),'\'];
    end
    if days_marker(1,i)>=10
    filename2=['H:\p17\Right\d',num2str(days_marker(1,i)),'\'];
    end
    
load([filename1,'\','movement_epoch_select']); %trial的信息
load([filename1,'\','movement_epoch_frames']); %trial的信息
load([filename1,'\','sigtdf']);

movement_select_left=movement_epoch_select;
movement_frames_left=movement_epoch_frames;
sigt_left=sigtdf;



load([filename2,'\','movement_epoch_select']); %trial的信息
load([filename2,'\','movement_epoch_frames']); %trial的信息
load([filename2,'\','sigtdf']);

movement_select_right=movement_epoch_select;
movement_frames_right=movement_epoch_frames;
sigt_right=sigtdf;



sigt=[sigt_left,sigt_right];
left_frame=size(sigt_left,2);
sigt_left_after=sigt(:,1:left_frame);
sigt_right_after=sigt(:,left_frame+1:end);
% for neu=1:size(sigt,1)
% sigt(neu,:)=normalize(sigt(neu,:));
% end



% calcium detect
for neu=1:size(sigt,1)
[frames amplitudes] = AP_trace_peak(sigt(neu,:));
peak_frames{1,neu}=frames;
peak_amplitudes{1,neu}=amplitudes;
end
for neu=1:size(sigt,1)
sigt_before=sigt(neu,:);
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
event_segment=sigt_before(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_frames{1,neu}{1,1}(1,peak_num)+20);
peak_pos=find(event_segment==max(event_segment));
peak_end_frames{1,neu}(1,peak_num)=peak_frames{1,neu}{1,1}(1,peak_num)+peak_pos;
end
else
peak_end_frames{1,neu}=[];
end
end
for neu=1:size(sigt,1)
sigt_after=zeros(1,size(sigt(neu,:),2));
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
sigt_after(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_end_frames{1,neu}(1,peak_num))=peak_amplitudes{1,neu}{1,1}(1,peak_num);
end
end
calcium_event(neu,:)=sigt_after;
end

ca_left_after=calcium_event(:,1:left_frame);
ca_right_after=calcium_event(:,left_frame+1:end);



%% 根据运动学信息的相似性筛选新的trial
for i=1:size(movement_frames_left,1)
X=movement_frames_left(i,30:end);
peak_pos=find(X==max(X));
trial_peak(i,1)=peak_pos(1,1);
 end
 movement_data_new=[movement_select_left,trial_peak];
 movement_new=sortrows( movement_data_new,3);
 movement_se=movement_new(floor(size(movement_new,1)*0.2):ceil(size(movement_new,1)*0.8),:);


%% 按照trial提取神经元的数据
pre=0;
post=59;
for neu=1:size(sigt_left_after,1)
for trial=1:size(movement_se,1)
sigt_trial_select_left{neu,1}(trial,:)=sigt_left_after(neu, movement_se(trial,1)-pre:movement_se(trial,1)+post);
end
end
% 
% for neu=1:size(sigt_trial_select_left,1)
%     for trial=1:size(sigt_trial_select_left{neu,1},1)
% sigt_trial_select_left{neu,1}(trial,:)=normalize(sigt_trial_select_left{neu,1}(trial,:));
%     end
% end


for neu=1:size(sigt_trial_select_left,1)
sigt_mean_select_left(neu,:)=mean(sigt_trial_select_left{neu,1});
end





for neu=1:size(ca_left_after,1)
for trial=1:size(movement_se,1)
ca_trial_select_left{neu,1}(trial,:)=ca_left_after(neu, movement_se(trial,1)-pre:movement_se(trial,1)+post);
end
end

for neu=1:size(ca_trial_select_left,1)
ca_mean_select_left(neu,:)=mean(ca_trial_select_left{neu,1});
end
save([filename1,'\','ca_trial_select_left_no'],'ca_trial_select_left');
save([filename1,'\','sigt_trial_select_left_no'],'sigt_trial_select_left');
% save([filename1,'\','sigt_mean_select_left'],'sigt_mean_select_left');
% save([filename1,'\','ca_mean_select_left'],'ca_mean_select_left');
save([filename1,'\','movement_se'],'movement_se');

movement_data_new=[];
movement_new=[];
trial_peak=[];
movement_se=[];

for i=1:size(movement_frames_right,1)
X=movement_frames_right(i,30:end);
peak_pos=find(X==max(X));
trial_peak(i,1)=peak_pos(1,1);
 end
 movement_data_new=[movement_select_right,trial_peak];
 movement_new=sortrows( movement_data_new,3);
 movement_se=movement_new(floor(size(movement_new,1)*0.2):ceil(size(movement_new,1)*0.8),:);

 for neu=1:size(sigt_right_after,1)
for trial=1:size(movement_se,1)
sigt_trial_select_right{neu,1}(trial,:)=sigt_right_after(neu, movement_se(trial,1)-pre:movement_se(trial,1)+post);
end
end

for neu=1:size(sigt_trial_select_right,1)
sigt_mean_select_right(neu,:)=mean(sigt_trial_select_right{neu,1});
end

for neu=1:size(ca_right_after,1)
for trial=1:size(movement_se,1)
ca_trial_select_right{neu,1}(trial,:)=ca_right_after(neu, movement_se(trial,1)-pre:movement_se(trial,1)+post);
end
end

for neu=1:size(ca_trial_select_right,1)
ca_mean_select_right(neu,:)=mean(ca_trial_select_right{neu,1});
end
save([filename2,'\','ca_trial_select_right_no'],'ca_trial_select_right');
save([filename2,'\','sigt_trial_select_right_no'],'sigt_trial_select_right');
% save([filename2,'\','sigt_mean_select_right'],'sigt_mean_select_right');
% save([filename2,'\','ca_mean_select_right'],'ca_mean_select_right');
save([filename2,'\','movement_se'],'movement_se');



sigt_mean_select_left=[];
sigt_trial_select_left=[];
ca_mean_select_left=[];
ca_trial_select_left=[];
calcium_event=[];
sigt_after=[];
sigt_before=[];
sigt_mean_select_right=[];
sigt_trial_select_right=[];
ca_mean_select_right=[];
ca_trial_select_right=[];
movement_data_new=[];
movement_new=[];
trial_peak=[];
movement_se=[];
end
clc;clear; close all
%% data input
days_marker=[2,3,4,5,9,13,19,20,23,24,26,27];
for d=1:size(days_marker,2)
if days_marker(1,d)<10
filename=['H:\p01\Left\d0',num2str(days_marker(1,d)),'\'];
angle=load([filename,'p01_d0',num2str(days_marker(1,d)),'_left.txt']);
end
if days_marker(1,d)>=10
 filename=['H:\p01\Left\d',num2str(days_marker(1,d)),'\'];
 angle=load([filename,'p01_d',num2str(days_marker(1,d)),'_left.txt']);
end
angle_data=angle(:,4);
load([filename,'angle_downsample']);
load([filename,'\','trial_select']);
angle_fps=200;
frame_fps=30;
trial_length=0.5;%单位是s
%% 对运动数据进行预处理
%基线去除
baseline_removed=detrend(angle_data,'constant');
for i=1:size(baseline_removed,2)
baseline_removed(i)=(baseline_removed(i)>=0)*baseline_removed(i);
end
xx=sort(baseline_removed);
baseline=mean(xx(1:20000));
for i=1:size(baseline_removed,1)
if baseline_removed(i)<baseline
 baseline_removed(i)=baseline;
end
end
angle_remove_baseline=baseline_removed;
%平滑
widthmean=40;
% for i=1+widthmean:size(angle_remove_baseline,1)-widthmean
% angle_filter(1,i)=median(angle_remove_baseline(i+(-widthmean:widthmean)));
% end
angle_smooth=smooth(angle_remove_baseline,widthmean);
%滤波
% fp1=5; fs1=15;
% Fs2=angle_fps/2;
% wp=fp1/Fs2; ws=fs1/Fs2;
% rp=1;rs=30;
% [n,wn]=buttord(wp,ws,rp,rs);
% [b2,a2]=butter(n,wn,'low','s');
% y=filter(b2,a2,angle_remove_baseline);
 for i=1:size(pushing_val)
movement_data(i,:)=angle_smooth(round(pushing_val(i,1)/30*200):round(pushing_val(i,1)/frame_fps*angle_fps)+trial_length*angle_fps,1);
 end
 
  for i=1:size(movement_data)
X=movement_data(i,:);
peak_pos=find(X==max(X));
trial_peak(i,1)=peak_pos(1,1);
 end
 movement_data_new=[movement_data,trial_peak];
 movement_new=sortrows(movement_data_new,trial_length*angle_fps+2);
 movement_se=movement_new(floor(size(movement_new,1)*0.2):ceil(size(movement_new,1)*0.8),:);
%% 计算correlation
k=0;
for i=1:size(movement_se,1)-1
for j=i:size(movement_se,1)
 k=k+1;
R=corrcoef(movement_se(i,:),movement_se(j,:));
r(k,1)=R(1,2);
end
end
r_mean=mean(abs(r));
r_session(d,1)=r_mean;
movement_se=[];
movement_data_new=[];
movement_data=[];
r=[];
trial_peak=[];
end

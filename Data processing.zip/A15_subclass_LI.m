clc;clear;close all
filename='E:\Corticospinal Data\g19';
days_marker=[5,7,8,14,18,22];
for d=1:size(days_marker,2)
%% data input
load([filename,'\','neuron_LI_new_',num2str(days_marker(1,d))]);
neuron_LI_all{1,d}=neuron_LI;
end
for s=1:size(neuron_LI_all,2)
sigt_LI=neuron_LI_all{1,s};
con1_pos=find(sigt_LI==-1);
con2_pos=find(sigt_LI==1);
pos3=find(sigt_LI<0);
con3_pos=setdiff(pos3,con1_pos);
pos4=find(sigt_LI>0);
con4_pos=setdiff(pos4,con2_pos);
LI_type(1,1)=sum( sigt_LI(con1_pos))/size(sigt_LI,1);
LI_type(1,2)=sum( sigt_LI(con2_pos))/size(sigt_LI,1);
LI_type(1,3)=sum( sigt_LI(con3_pos))/size(sigt_LI,1);
LI_type(1,4)=sum( sigt_LI(con4_pos))/size(sigt_LI,1);
LI_num(1,1)=size(con1_pos,1)/size(sigt_LI,1);
LI_num(1,2)=size(con2_pos,1)/size(sigt_LI,1);
LI_num(1,3)=size(con3_pos,1)/size(sigt_LI,1);
LI_num(1,4)=size(con4_pos,1)/size(sigt_LI,1);
LI_type_all{1,s}=LI_type;
LI_num_all{1,s}=LI_num;
end
for class=1:4
for s=1:size(LI_type_all,2)
neu_LI_change(class,s)=LI_type_all{1,s}(1,class);
neu_num_change(class,s)=LI_num_all{1,s}(1,class);
 end
end
class_type={'ipsi-preferring','contra-preferring','bilateral-preferring-ipsi','bilateral-preferring-contra'};

for i=1:size(neu_LI_change,1)
    figure(i)
plot(neu_LI_change(i,:),'k');
% hold on;
% plot(neu_num_change(i,:),'r');
title(class_type{1,i});
end
for i=1:size(neu_num_change,1)
    figure(i+4)
plot(neu_num_change(i,:),'k');
% hold on;
% plot(neu_num_change(i,:),'r');
title(class_type{1,i});
end
clc;clear;close all

epoch_or_frame=1; %1����epoch,0����frame
filename='E:\Corticospinal Data\p21\Left\d07\';
load([filename,'\','Fall']);
if epoch_or_frame==1
load([filename,'\','movement_epoch_select']);
movement_left=movement_epoch_select;
end
if epoch_or_frame==0
load([filename,'\','movement_frames']);
movement_left=movement_frames;
end
pos=find(iscell(:,1)==1);
load([filename,'\','calcium_event']);
F_left=calcium_event;
load([filename,'\','neu_marker_m']);
marker_left=neu_marker;

filename='E:\Corticospinal Data\p21\Right\d07\';
if epoch_or_frame==1
load([filename,'\','movement_epoch_select']);
movement_right=movement_epoch_select;
end
if epoch_or_frame==0
load([filename,'\','movement_frames']);
movement_right=movement_frames;
end
load([filename,'\','calcium_event']);
F_right=calcium_event;
load([filename,'\','neu_marker_m']);
marker_right=neu_marker;
marker=marker_left+marker_right;

%% ��ȡ�˶��ڼ��Fֵ
if epoch_or_frame==1
F_left_task=[];F_right_task=[];
for i=1:size(movement_left,1)
F_left_task=[F_left_task F_left(:,movement_left(i,1)+30:movement_left(i,2))];
end
for i=1:size(movement_right,1)
F_right_task=[F_right_task F_right(:,movement_right(i,1)+30:movement_right(i,2))];
end
end
if epoch_or_frame==0
F_left_task=F_left(:,movement_left);
F_right_task=F_right(:,movement_right);
end

%% �ҳ���ͬ�Բ������Բ������Ԫ
for neu=1:size(F_left_task,1)
[p(neu,1),q(neu,1)]=ranksum(F_left_task(neu,:),F_right_task(neu,:));
end

%% ���������ֵ����
for neu=1:size(F_left_task,1)
diff_mean(neu,1)=mean(F_left_task(neu,:))-mean(F_right_task(neu,:));
end

%% �Բ�ͬ�����񾭱���marker(0������˶��޹أ�1��>�ң�2 ��>��, 3 �˶���ص�˫���޲��죩
neuron_marker=ones(1,size(F_left_task,1))*3;
neu_pos=find(marker==0);
neuron_marker(neu_pos)=0;
diff_pos=find(p<0.05);
neuron_marker(diff_pos)=1;
for i=1:size(diff_mean,1)
if neuron_marker(1,i)==1&&diff_mean(i,1)<0
neuron_marker(1,i)=2;
end
end
h=filename(34:35);
% h=filename(15:16);
filename='E:\Corticospinal Data\p21\';
save([filename,'\','neuron_df_marker_',num2str(h)],'neuron_marker');

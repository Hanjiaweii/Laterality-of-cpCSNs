function  calcium_select=epoch_select( calcium_event, movement_trial,pre,post)
for neu=1:size(calcium_event,1)
 XX=[];
for trial=1:size( movement_trial,1)
XX=[XX, calcium_event(neu, movement_trial(trial,1)-pre: movement_trial(trial,1)+post)];
end
calcium_select(neu,:)=XX;
end
end
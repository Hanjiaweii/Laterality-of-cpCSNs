clc;close all; clear;
%% data input
days_marker=[5,8, 22];
for i=1:size(days_marker,2)
    if days_marker(1,i)<10
    filename1=['E:\Corticospinal Data\g19\Left\d0',num2str(days_marker(1,i)),'\'];
    end
    if days_marker(1,i)>=10
    filename1=['E:\Corticospinal Data\g19\Left\d',num2str(days_marker(1,i)),'\'];
    end
    load([filename1,'gc_p.mat']);
     load([filename1,'gc_value.mat']);
    gc_all{1,i}=sig;
    gc_v_all{1,i}=F;
    load([filename1,'Fall.mat']);
    neu_pos_info{1,i}=stat;
    neu_pos_info{2,i}=iscell;
    if days_marker(1,i)<10
    filename2=['E:\Corticospinal Data\g19\Right\d0',num2str(days_marker(1,i)),'\'];
    end
    if days_marker(1,i)>=10
    filename2=['E:\Corticospinal Data\g19\Right\d',num2str(days_marker(1,i)),'\'];
    end
     load([filename2,'gc_p.mat']);
     load([filename2,'gc_value.mat']);
    gc_all{2,i}=sig;
    gc_v_all{2,i}=F;
    filename='E:\Corticospinal Data\g19';
     load([filename,'\','neuron_LI_new_',num2str(days_marker(1,i))]);
     neu_type_all{1,i}=neuron_LI;
    
end

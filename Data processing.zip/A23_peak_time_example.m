clc;clear;close all

filename='E:\Corticospinal Data\p19';
days_marker=[14];


for d=1:size(days_marker,2)
%% data input
load([filename,'\','neuron_LI_new_',num2str(days_marker(1,d))]);
if  days_marker(1,d)<10
filename1=['E:\Corticospinal Data\p19\Left\d0',num2str(days_marker(1,d)),'\'];
filename2=['E:\Corticospinal Data\p19\Right\d0',num2str(days_marker(1,d)),'\'];
end
if  days_marker(1,d)>10
filename1=['E:\Corticospinal Data\p19\Left\d',num2str(days_marker(1,d)),'\'];
filename2=['E:\Corticospinal Data\p19\Right\d',num2str(days_marker(1,d)),'\'];    
end
pre=0;
post=59;
load([filename1,'movement_se.mat']);
load([filename1,'sigtdf.mat']);
sigt_left=sigtdf;
left_frame=size(sigt_left,2);
movement_left=movement_se;
load([filename2,'movement_se.mat']);
load([filename2,'movement_epoch_select.mat']);
load([filename2,'sigtdf.mat']);
sigt_right=sigtdf;
movement_right=movement_se;



%% Normalize
sigt=[sigt_left,sigt_right];
for neu=1:size(sigt,1)
sigt(neu,:)=normalize(sigt(neu,:));
end
sigt_after_left=sigt(:,1:left_frame);
sigt_after_right=sigt(:,left_frame+1:end);

for neu=1:size(sigt,1)
[frames amplitudes] = AP_trace_peak(sigt(neu,:));
peak_frames{1,neu}=frames;
peak_amplitudes{1,neu}=amplitudes;
end
for neu=1:size(sigt,1)
sigt_before=sigt(neu,:);
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
event_segment=sigt_before(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_frames{1,neu}{1,1}(1,peak_num)+20);
peak_pos=find(event_segment==max(event_segment));
peak_end_frames{1,neu}(1,peak_num)=peak_frames{1,neu}{1,1}(1,peak_num)+peak_pos;
end
else
peak_end_frames{1,neu}=[];
end
end
for neu=1:size(sigt,1)
sigt_after=zeros(1,size(sigt(neu,:),2));
if size(peak_frames{1,neu}{1,1},1)>0
for peak_num=1:size(peak_frames{1,neu}{1,1},2)
sigt_after(1,peak_frames{1,neu}{1,1}(1,peak_num):peak_end_frames{1,neu}(1,peak_num))=peak_amplitudes{1,neu}{1,1}(1,peak_num);
end
end
calcium_event(neu,:)=sigt_after;
end
calcium_left=calcium_event(:,1:left_frame);
calcium_right=calcium_event(:,left_frame+1:end);


for neu=1:size(calcium_left,1)
for trial=1:size(movement_left,1)
sigt_i{neu,1}(trial,:)=calcium_left(neu,movement_left(trial,1)-pre: movement_left(trial,1)+post);
end
end
for neu=1:size(calcium_right,1)
for trial=1:size(movement_right,1)
sigt_c{neu,1}(trial,:)=calcium_right(neu,movement_right(trial,1)-pre: movement_right(trial,1)+post);
end
end

for neu=1:size(sigt_i,1)
sigt_i_mean(neu,:)=mean(sigt_i{neu,1});
end

for neu=1:size(sigt_c,1)
sigt_c_mean(neu,:)=mean(sigt_c{neu,1});
end


%% 按不同类别的神经元在同对侧运动时的发放整理数据
con1_pos=find(neuron_LI==-1);
con2_pos=find(neuron_LI==1);
pos3=find(neuron_LI<0);
con3_pos=setdiff(pos3,con1_pos);
pos4=find(neuron_LI>0);
con4_pos=setdiff(pos4,con2_pos);
con5_pos=find(neuron_LI==0);
neu_class={con1_pos,con2_pos,con3_pos,con4_pos,con5_pos};

for neu_type=1:5
sigt_i_all=sigt_i_mean(neu_class{1,neu_type},:);
sigt_c_all=sigt_c_mean(neu_class{1,neu_type},:);
length=12;
gap_num=60/length;
for i=1:size(sigt_i_all,1)
for j=1:gap_num
gap=(j-1)*length+1:j*length;
sigt_i_all2(i,j)=sum(sigt_i_all(i,gap));
sigt_c_all2(i,j)=sum(sigt_c_all(i,gap));
end
end


for i=1:size(sigt_i_all2,1)
if sum(sigt_i_all2(i,:))>0
max_pos1=find(sigt_i_all2(i,:)==max(sigt_i_all2(i,:)));
sigt_i_all2(i,:)=0;
sigt_i_all2(i,max_pos1)=1;
end
if sum(sigt_c_all2(i,:))>0
max_pos2=find(sigt_c_all2(i,:)==max(sigt_c_all2(i,:)));
sigt_c_all2(i,:)=0;
sigt_c_all2(i,max_pos2)=1;
end
end

for i=1:gap_num
 sigt_i_p(1,i)=sum(sum(sigt_i_all2(:,i)))/size(sigt_i_all2,1);
 sigt_c_p(1,i)=sum(sum(sigt_c_all2(:,i)))/size(sigt_c_all2,1);
end


sigt_i_p_all(neu_type,:)=sigt_i_p;
sigt_c_p_all(neu_type,:)=sigt_c_p;
sigt_i_all=[];
sigt_c_all=[];
 sigt_i_p=[];
  sigt_c_p=[];
 figure(neu_type)
  subplot(121)
  bar(sigt_i_p_all(neu_type,:));
  ylim([0,1]);
    subplot(122)
  bar(sigt_c_p_all(neu_type,:));
  ylim([0,1]);
  
end
end
